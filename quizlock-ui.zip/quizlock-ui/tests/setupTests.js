import '@testing-library/jest-dom';

// Mock Electron APIs globally
const mockElectronAPI = {
  getSystemInfo: jest.fn().mockResolvedValue({
    version: '1.0.0',
    mode: 'test',
    screen: { width: 1920, height: 1080 }
  }),
  requestTeacherOverride: jest.fn().mockResolvedValue(true),
  validateTeacherPassword: jest.fn().mockResolvedValue(true),
  exitGateMode: jest.fn().mockResolvedValue(true),
  testGateMode: jest.fn().mockResolvedValue(true),
  onSystemEvent: jest.fn(),
  removeSystemEventListener: jest.fn(),
  startStudySession: jest.fn().mockResolvedValue(true),
  getDueCards: jest.fn().mockResolvedValue([]),
  submitRating: jest.fn().mockResolvedValue(true),
  requestEmergencyExit: jest.fn().mockResolvedValue(true),
  getSettings: jest.fn().mockResolvedValue({
    gateEnabled: true,
    requiredCorrectAnswers: 5,
    maxCardsPerSession: 20
  }),
  updateSettings: jest.fn().mockResolvedValue(true),
  getStudentStats: jest.fn().mockResolvedValue([]),
  getSystemStats: jest.fn().mockResolvedValue({
    totalStudents: 0,
    totalSubmissions: 0,
    averageAccuracy: 0
  }),
  getLogs: jest.fn().mockResolvedValue([]),
  forceUnlockStudent: jest.fn().mockResolvedValue(true)
};

// Mock window.electronAPI
Object.defineProperty(window, 'electronAPI', {
  value: mockElectronAPI,
  writable: true
});

// Mock ResizeObserver
global.ResizeObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));

// Mock matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // deprecated
    removeListener: jest.fn(), // deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

// Mock IntersectionObserver
global.IntersectionObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));

// Mock requestAnimationFrame
global.requestAnimationFrame = jest.fn().mockImplementation(cb => setTimeout(cb, 0));
global.cancelAnimationFrame = jest.fn().mockImplementation(id => clearTimeout(id));

// Mock HTMLElement methods
HTMLElement.prototype.scrollIntoView = jest.fn();
HTMLElement.prototype.focus = jest.fn();
HTMLElement.prototype.blur = jest.fn();

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
global.localStorage = localStorageMock;

// Mock sessionStorage
const sessionStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
global.sessionStorage = sessionStorageMock;

// Mock crypto API for testing
Object.defineProperty(global, 'crypto', {
  value: {
    randomUUID: jest.fn(() => '00000000-0000-0000-0000-000000000000'),
    getRandomValues: jest.fn((arr) => {
      for (let i = 0; i < arr.length; i++) {
        arr[i] = Math.floor(Math.random() * 256);
      }
      return arr;
    }),
  },
});

// Mock console methods to reduce noise in tests
global.console = {
  ...console,
  // Uncomment to suppress console.log in tests
  // log: jest.fn(),
  // info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
};

// Add custom matchers
expect.extend({
  toBeVisible(received) {
    const pass = received.style.display !== 'none' && received.style.visibility !== 'hidden';
    return {
      message: () => `expected element to ${pass ? 'not ' : ''}be visible`,
      pass,
    };
  },
  toHaveAccessibleName(received) {
    const pass = received.getAttribute('aria-label') || 
                 received.textContent || 
                 received.getAttribute('title') || 
                 received.getAttribute('aria-labelledby');
    return {
      message: () => `expected element to ${pass ? 'not ' : ''}have accessible name`,
      pass: !!pass,
    };
  }
});

// Setup for testing library
beforeEach(() => {
  // Clear all mocks before each test
  jest.clearAllMocks();
  
  // Reset localStorage
  localStorage.clear();
  sessionStorage.clear();
  
  // Reset electron API mocks to defaults
  mockElectronAPI.getSystemInfo.mockResolvedValue({
    version: '1.0.0',
    mode: 'test',
    screen: { width: 1920, height: 1080 }
  });
});

// Global test cleanup
afterEach(() => {
  // Clean up any timers, intervals, etc.
  jest.clearAllTimers();
  jest.useRealTimers();
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Optionally fail the test
  // throw reason;
});

// Increase timeout for integration tests
jest.setTimeout(15000);