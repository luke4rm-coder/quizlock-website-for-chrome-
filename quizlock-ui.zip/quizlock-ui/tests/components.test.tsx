import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import userEvent from '@testing-library/user-event';

// Import components to test
import App from '../src/renderer/App';
import GateScreen from '../src/renderer/components/GateScreen';
import MainScreen from '../src/renderer/components/MainScreen';
import TeacherDashboard from '../src/renderer/components/TeacherDashboard';
import QuestionCard from '../src/renderer/components/QuestionCard';
import ClozeCard from '../src/renderer/components/ClozeCard';
import SummaryCard from '../src/renderer/components/SummaryCard';

// Mock electron API
const mockElectronAPI = {
  getSystemInfo: jest.fn().mockResolvedValue({
    version: '1.0.0',
    mode: 'test'
  }),
  requestTeacherOverride: jest.fn().mockResolvedValue(true),
  validateTeacherPassword: jest.fn().mockResolvedValue(true),
  exitGateMode: jest.fn().mockResolvedValue(true),
  onSystemEvent: jest.fn(),
  removeSystemEventListener: jest.fn(),
  testGateMode: jest.fn().mockResolvedValue(true)
};

// Set up global window mock
Object.defineProperty(window, 'electronAPI', {
  value: mockElectronAPI,
  writable: true
});

// Mock data for testing
const mockFlashcard = {
  id: '1',
  type: 'question' as const,
  question: 'What is the capital of France?',
  answer: 'Paris',
  submittedSummary: 'This article discussed European capitals.',
  originalText: 'Paris is the capital and most populous city of France.'
};

const mockClozeCard = {
  id: '2',
  type: 'cloze' as const,
  question: 'The capital of France is _____.',
  answer: 'Paris',
  submittedSummary: 'Geography facts about France.',
  originalText: 'France is a country in Western Europe.'
};

const mockSummaryCard = {
  id: '3',
  type: 'summary' as const,
  originalText: 'Paris is the capital of France and a major European city.',
  submittedSummary: 'Article about Paris being the capital of France.'
};

const mockSystemInfo = {
  version: '1.0.0',
  mode: 'test',
  screen: { width: 1920, height: 1080 }
};

describe('QuizLock Components', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('App Component', () => {
    it('renders loading state initially', () => {
      render(<App mode="normal" isPrimary={true} />);
      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('renders MainScreen in normal mode after loading', async () => {
      render(<App mode="normal" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      });

      expect(screen.getByText('QuizLock Dashboard')).toBeInTheDocument();
    });

    it('renders GateScreen in gate mode', async () => {
      render(<App mode="gate" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      });

      expect(screen.getByText('🔒 Learning Gate Active')).toBeInTheDocument();
    });

    it('handles teacher override shortcut', async () => {
      render(<App mode="gate" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      });

      // Simulate Ctrl+Shift+T
      fireEvent.keyDown(document, {
        key: 'T',
        ctrlKey: true,
        shiftKey: true
      });

      expect(mockElectronAPI.requestTeacherOverride).toHaveBeenCalled();
    });

    it('opens teacher dashboard with shortcut', async () => {
      render(<App mode="normal" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      });

      // Simulate Ctrl+Shift+D
      fireEvent.keyDown(document, {
        key: 'D',
        ctrlKey: true,
        shiftKey: true
      });

      expect(screen.getByText('🎓 QuizLock Teacher Dashboard')).toBeInTheDocument();
    });
  });

  describe('QuestionCard Component', () => {
    const mockProps = {
      flashcard: mockFlashcard,
      onRate: jest.fn(),
      showKeyboardHints: true
    };

    it('renders question correctly', () => {
      render(<QuestionCard {...mockProps} />);
      
      expect(screen.getByText('What is the capital of France?')).toBeInTheDocument();
      expect(screen.getByText('Show Answer')).toBeInTheDocument();
    });

    it('shows answer when button clicked', async () => {
      const user = userEvent.setup();
      render(<QuestionCard {...mockProps} />);
      
      await user.click(screen.getByText('Show Answer'));
      
      expect(screen.getByText('Paris')).toBeInTheDocument();
      expect(screen.getByText('Rate your knowledge:')).toBeInTheDocument();
    });

    it('calls onRate when rating button clicked', async () => {
      const user = userEvent.setup();
      render(<QuestionCard {...mockProps} />);
      
      // Show answer first
      await user.click(screen.getByText('Show Answer'));
      
      // Click rating
      await user.click(screen.getByText('Good (3)'));
      
      expect(mockProps.onRate).toHaveBeenCalledWith(3);
    });

    it('handles keyboard rating', () => {
      render(<QuestionCard {...mockProps} />);
      
      // Show answer first
      fireEvent.click(screen.getByText('Show Answer'));
      
      // Simulate keyboard rating
      fireEvent.keyDown(document, { key: '4' });
      
      expect(mockProps.onRate).toHaveBeenCalledWith(4);
    });
  });

  describe('ClozeCard Component', () => {
    const mockProps = {
      flashcard: mockClozeCard,
      onRate: jest.fn(),
      showKeyboardHints: true
    };

    it('renders cloze question correctly', () => {
      render(<ClozeCard {...mockProps} />);
      
      expect(screen.getByText('The capital of France is _____.')).toBeInTheDocument();
      expect(screen.getByPlaceholderText('Your answer...')).toBeInTheDocument();
    });

    it('accepts user input and shows feedback', async () => {
      const user = userEvent.setup();
      render(<ClozeCard {...mockProps} />);
      
      const input = screen.getByPlaceholderText('Your answer...');
      await user.type(input, 'Paris');
      await user.click(screen.getByText('Submit'));
      
      expect(screen.getByText('Correct Answer: Paris')).toBeInTheDocument();
      expect(screen.getByText('✅ Correct!')).toBeInTheDocument();
    });

    it('handles incorrect answers', async () => {
      const user = userEvent.setup();
      render(<ClozeCard {...mockProps} />);
      
      const input = screen.getByPlaceholderText('Your answer...');
      await user.type(input, 'London');
      await user.click(screen.getByText('Submit'));
      
      expect(screen.getByText('❌ Incorrect')).toBeInTheDocument();
    });
  });

  describe('SummaryCard Component', () => {
    const mockProps = {
      flashcard: mockSummaryCard,
      onRate: jest.fn(),
      showKeyboardHints: true
    };

    it('renders summary card correctly', () => {
      render(<SummaryCard {...mockProps} />);
      
      expect(screen.getByText('Recall Summary')).toBeInTheDocument();
      expect(screen.getByPlaceholderText('Write your summary here...')).toBeInTheDocument();
    });

    it('accepts summary input', async () => {
      const user = userEvent.setup();
      render(<SummaryCard {...mockProps} />);
      
      const textarea = screen.getByPlaceholderText('Write your summary here...');
      await user.type(textarea, 'My summary about Paris');
      
      expect(textarea).toHaveValue('My summary about Paris');
    });

    it('shows comparison after submission', async () => {
      const user = userEvent.setup();
      render(<SummaryCard {...mockProps} />);
      
      const textarea = screen.getByPlaceholderText('Write your summary here...');
      await user.type(textarea, 'My summary about Paris');
      await user.click(screen.getByText('Submit Summary'));
      
      expect(screen.getByText('Your Summary')).toBeInTheDocument();
      expect(screen.getByText('Original Summary')).toBeInTheDocument();
    });
  });

  describe('MainScreen Component', () => {
    const mockProps = {
      systemInfo: mockSystemInfo
    };

    it('renders dashboard correctly', () => {
      render(<MainScreen {...mockProps} />);
      
      expect(screen.getByText('QuizLock Dashboard')).toBeInTheDocument();
      expect(screen.getByText('📚 Start Study Session')).toBeInTheDocument();
      expect(screen.getByText('🔒 Test Gate Mode')).toBeInTheDocument();
    });

    it('displays system stats', () => {
      render(<MainScreen {...mockProps} />);
      
      expect(screen.getByText('Total Cards')).toBeInTheDocument();
      expect(screen.getByText('Due Today')).toBeInTheDocument();
      expect(screen.getByText('Studied Today')).toBeInTheDocument();
    });

    it('handles test gate mode click', async () => {
      const user = userEvent.setup();
      render(<MainScreen {...mockProps} />);
      
      await user.click(screen.getByText('🔒 Test Gate Mode'));
      
      expect(mockElectronAPI.testGateMode).toHaveBeenCalled();
    });
  });

  describe('TeacherDashboard Component', () => {
    const mockProps = {
      onClose: jest.fn()
    };

    it('renders teacher dashboard', async () => {
      render(<TeacherDashboard {...mockProps} />);
      
      await waitFor(() => {
        expect(screen.getByText('🎓 QuizLock Teacher Dashboard')).toBeInTheDocument();
      });
      
      expect(screen.getByText('📊 Overview')).toBeInTheDocument();
      expect(screen.getByText('👥 Students')).toBeInTheDocument();
      expect(screen.getByText('⚙️ Settings')).toBeInTheDocument();
    });

    it('switches between tabs', async () => {
      const user = userEvent.setup();
      render(<TeacherDashboard {...mockProps} />);
      
      await waitFor(() => {
        expect(screen.getByText('🎓 QuizLock Teacher Dashboard')).toBeInTheDocument();
      });

      await user.click(screen.getByText('👥 Students'));
      
      expect(screen.getByText('Student Management')).toBeInTheDocument();
    });

    it('closes when close button clicked', async () => {
      const user = userEvent.setup();
      render(<TeacherDashboard {...mockProps} />);
      
      await waitFor(() => {
        expect(screen.getByText('🎓 QuizLock Teacher Dashboard')).toBeInTheDocument();
      });

      await user.click(screen.getByText('×'));
      
      expect(mockProps.onClose).toHaveBeenCalled();
    });
  });

  describe('GateScreen Component', () => {
    const mockProps = {
      isPrimary: true,
      systemInfo: mockSystemInfo
    };

    // Mock flashcards for gate screen
    beforeEach(() => {
      // Mock the flashcard loading
      jest.spyOn(window.electronAPI, 'getSystemInfo').mockResolvedValue({
        ...mockSystemInfo,
        dueCards: [mockFlashcard, mockClozeCard, mockSummaryCard]
      });
    });

    it('renders gate screen with progress', async () => {
      render(<GateScreen {...mockProps} />);
      
      expect(screen.getByText('🔒 Learning Gate Active')).toBeInTheDocument();
      expect(screen.getByText('Complete your review to unlock')).toBeInTheDocument();
    });

    it('shows progress bar', () => {
      render(<GateScreen {...mockProps} />);
      
      expect(screen.getByText('Progress: 0 / 5')).toBeInTheDocument();
    });

    it('displays emergency exit option', () => {
      render(<GateScreen {...mockProps} />);
      
      expect(screen.getByText('🆘 Emergency Exit')).toBeInTheDocument();
    });
  });

  describe('Integration Tests', () => {
    it('completes full gate session flow', async () => {
      const user = userEvent.setup();
      
      // Start in gate mode
      render(<App mode="gate" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.getByText('🔒 Learning Gate Active')).toBeInTheDocument();
      });

      // Should show the first flashcard
      await waitFor(() => {
        expect(screen.getByText('Show Answer')).toBeInTheDocument();
      });

      // Complete the first card
      await user.click(screen.getByText('Show Answer'));
      await user.click(screen.getByText('Good (3)'));

      // Progress should update
      expect(screen.getByText('Progress: 1 / 5')).toBeInTheDocument();
    });

    it('handles teacher dashboard workflow', async () => {
      const user = userEvent.setup();
      
      // Start in normal mode
      render(<App mode="normal" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.getByText('QuizLock Dashboard')).toBeInTheDocument();
      });

      // Open teacher dashboard
      fireEvent.keyDown(document, {
        key: 'D',
        ctrlKey: true,
        shiftKey: true
      });

      expect(screen.getByText('🎓 QuizLock Teacher Dashboard')).toBeInTheDocument();

      // Navigate to settings
      await user.click(screen.getByText('⚙️ Settings'));
      expect(screen.getByText('System Settings')).toBeInTheDocument();

      // Close dashboard
      await user.click(screen.getByText('×'));
      expect(screen.getByText('QuizLock Dashboard')).toBeInTheDocument();
    });
  });

  describe('Error Handling', () => {
    it('handles API errors gracefully', async () => {
      mockElectronAPI.getSystemInfo.mockRejectedValueOnce(new Error('API Error'));
      
      render(<App mode="normal" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.getByText('Error')).toBeInTheDocument();
        expect(screen.getByText('API Error')).toBeInTheDocument();
      });
    });

    it('handles missing flashcards', () => {
      const props = {
        flashcard: { ...mockFlashcard, question: '', answer: '' },
        onRate: jest.fn(),
        showKeyboardHints: true
      };

      render(<QuestionCard {...props} />);
      
      // Should still render without crashing
      expect(screen.getByText('Show Answer')).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('has proper ARIA labels', () => {
      render(<MainScreen systemInfo={mockSystemInfo} />);
      
      const buttons = screen.getAllByRole('button');
      buttons.forEach(button => {
        expect(button).toHaveAccessibleName();
      });
    });

    it('supports keyboard navigation', async () => {
      const user = userEvent.setup();
      render(<MainScreen systemInfo={mockSystemInfo} />);
      
      const firstButton = screen.getByText('📚 Start Study Session');
      firstButton.focus();
      
      expect(firstButton).toHaveFocus();
      
      await user.keyboard('{Tab}');
      
      const nextButton = screen.getByText('🔒 Test Gate Mode');
      expect(nextButton).toHaveFocus();
    });
  });

  describe('Performance', () => {
    it('renders quickly without hanging', async () => {
      const startTime = performance.now();
      
      render(<App mode="normal" isPrimary={true} />);
      
      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      });
      
      const endTime = performance.now();
      expect(endTime - startTime).toBeLessThan(2000); // Should load in under 2 seconds
    });

    it('handles rapid state changes', async () => {
      const { rerender } = render(<App mode="normal" isPrimary={true} />);
      
      // Rapidly switch modes
      rerender(<App mode="gate" isPrimary={true} />);
      rerender(<App mode="normal" isPrimary={true} />);
      rerender(<App mode="gate" isPrimary={true} />);
      
      // Should not crash
      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
      });
    });
  });
});