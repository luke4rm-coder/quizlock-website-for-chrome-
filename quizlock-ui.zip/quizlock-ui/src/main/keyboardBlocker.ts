import { globalShortcut } from 'electron';

export class KeyboardBlocker {
  private isEnabled = false;
  private blockedShortcuts: string[] = [];
  private originalHandlers: Map<string, () => void> = new Map();

  // Additional shortcuts to block beyond those in main.ts
  private readonly ADDITIONAL_BLOCKED_SHORTCUTS = [
    'CommandOrControl+W', // Close window
    'CommandOrControl+Q', // Quit application
    'CommandOrControl+N', // New window
    'CommandOrControl+T', // New tab
    'CommandOrControl+Shift+N', // New incognito window
    'CommandOrControl+Shift+T', // Reopen closed tab
    'CommandOrControl+Shift+W', // Close all windows
    'CommandOrControl+M', // Minimize
    'CommandOrControl+H', // Hide (macOS)
    'Alt+Space', // System menu (Windows)
    'Alt+Enter', // Properties
    'Windows', // Start menu (Windows)
    'Meta', // Start menu (Linux)
    'Shift+F10', // Context menu
    'PrintScreen', // Screenshot
    'Alt+PrintScreen', // Window screenshot
    'CommandOrControl+PrintScreen', // Screenshot to clipboard
    'F1', // Help
    'F2', // Rename
    'F3', // Find next
    'F4', // Address bar
    'F5', // Refresh
    'F6', // Address bar focus
    'F7', // Spelling
    'F8', // Extension developer tools
    'F9', // Bookmarks
    'F10', // Menu bar
    'Shift+F11', // Exit fullscreen
    'CommandOrControl+1',
    'CommandOrControl+2',
    'CommandOrControl+3',
    'CommandOrControl+4',
    'CommandOrControl+5',
    'CommandOrControl+6',
    'CommandOrControl+7',
    'CommandOrControl+8',
    'CommandOrControl+9',
    'CommandOrControl+0',
    'CommandOrControl+Plus', // Zoom in
    'CommandOrControl+-', // Zoom out
    'CommandOrControl+0', // Reset zoom
    'CommandOrControl+L', // Address bar
    'CommandOrControl+K', // Search
    'CommandOrControl+E', // Search from address bar
    'CommandOrControl+F', // Find
    'CommandOrControl+G', // Find next
    'CommandOrControl+Shift+G', // Find previous
    'CommandOrControl+U', // View source
    'CommandOrControl+S', // Save
    'CommandOrControl+P', // Print
    'CommandOrControl+O', // Open
    'CommandOrControl+A', // Select all
    'CommandOrControl+C', // Copy
    'CommandOrControl+V', // Paste
    'CommandOrControl+X', // Cut
    'CommandOrControl+Z', // Undo
    'CommandOrControl+Y', // Redo
    'CommandOrControl+Shift+Z', // Redo
    'Backspace', // Browser back
    'Shift+Backspace', // Browser forward
    'Space', // Page down
    'Shift+Space', // Page up
    'Home', // Go to top
    'End', // Go to bottom
    'PageUp', // Page up
    'PageDown', // Page down
    'Escape' // Cancel/close dialogs
  ];

  constructor() {
    console.log('KeyboardBlocker initialized');
  }

  public enable(): void {
    if (this.isEnabled) {
      console.log('KeyboardBlocker already enabled');
      return;
    }

    console.log('Enabling keyboard blocking...');
    
    try {
      this.registerBlockedShortcuts();
      this.isEnabled = true;
      console.log(`Keyboard blocking enabled. Blocked ${this.blockedShortcuts.length} shortcuts.`);
    } catch (error) {
      console.error('Error enabling keyboard blocking:', error);
    }
  }

  public disable(): void {
    if (!this.isEnabled) {
      console.log('KeyboardBlocker already disabled');
      return;
    }

    console.log('Disabling keyboard blocking...');
    
    try {
      this.unregisterBlockedShortcuts();
      this.isEnabled = false;
      console.log('Keyboard blocking disabled');
    } catch (error) {
      console.error('Error disabling keyboard blocking:', error);
    }
  }

  private registerBlockedShortcuts(): void {
    // Register all additional blocked shortcuts
    this.ADDITIONAL_BLOCKED_SHORTCUTS.forEach(shortcut => {
      try {
        const success = globalShortcut.register(shortcut, () => {
          console.log(`Blocked shortcut: ${shortcut}`);
          // Do nothing - this effectively blocks the shortcut
          this.handleBlockedShortcut(shortcut);
        });

        if (success) {
          this.blockedShortcuts.push(shortcut);
        } else {
          console.warn(`Failed to register shortcut: ${shortcut} (may already be registered)`);
        }
      } catch (error) {
        console.warn(`Error registering shortcut ${shortcut}:`, error.message);
      }
    });

    // Additional platform-specific blocking
    this.registerPlatformSpecificShortcuts();
  }

  private registerPlatformSpecificShortcuts(): void {
    const platform = process.platform;

    if (platform === 'win32') {
      // Windows-specific shortcuts
      const windowsShortcuts = [
        'CommandOrControl+Escape', // Task Manager (Ctrl+Shift+Esc handled elsewhere)
        'CommandOrControl+Shift+Escape', // Task Manager
        'Windows+L', // Lock screen
        'Windows+R', // Run dialog
        'Windows+X', // Power user menu
        'Windows+I', // Settings
        'Windows+A', // Action center
        'Windows+S', // Search
        'Windows+E', // File explorer
        'Windows+D', // Show desktop
        'Windows+M', // Minimize all
        'Windows+Tab', // Task view
        'Alt+F4' // Close application - handled in main.ts but reinforced here
      ];

      windowsShortcuts.forEach(shortcut => {
        try {
          const success = globalShortcut.register(shortcut, () => {
            console.log(`Blocked Windows shortcut: ${shortcut}`);
            this.handleBlockedShortcut(shortcut);
          });

          if (success) {
            this.blockedShortcuts.push(shortcut);
          }
        } catch (error) {
          console.warn(`Error registering Windows shortcut ${shortcut}:`, error.message);
        }
      });
    } else if (platform === 'darwin') {
      // macOS-specific shortcuts
      const macShortcuts = [
        'Command+Option+Escape', // Force quit
        'Command+Space', // Spotlight
        'Command+Tab', // App switcher
        'Command+`', // Window switcher
        'Command+H', // Hide app
        'Command+Option+H', // Hide others
        'Command+M', // Minimize
        'Command+Option+M', // Minimize all
        'Command+W', // Close window
        'Command+Shift+W', // Close all windows
        'Command+Q' // Quit app
      ];

      macShortcuts.forEach(shortcut => {
        try {
          const success = globalShortcut.register(shortcut, () => {
            console.log(`Blocked macOS shortcut: ${shortcut}`);
            this.handleBlockedShortcut(shortcut);
          });

          if (success) {
            this.blockedShortcuts.push(shortcut);
          }
        } catch (error) {
          console.warn(`Error registering macOS shortcut ${shortcut}:`, error.message);
        }
      });
    }
  }

  private unregisterBlockedShortcuts(): void {
    // Unregister all blocked shortcuts
    this.blockedShortcuts.forEach(shortcut => {
      try {
        globalShortcut.unregister(shortcut);
      } catch (error) {
        console.warn(`Error unregistering shortcut ${shortcut}:`, error.message);
      }
    });

    this.blockedShortcuts = [];
    this.originalHandlers.clear();
  }

  private handleBlockedShortcut(shortcut: string): void {
    // Log the blocked attempt for monitoring/debugging
    console.log(`User attempted blocked shortcut: ${shortcut} at ${new Date().toISOString()}`);
    
    // Optional: Show a brief visual feedback that the action was blocked
    if (this.shouldShowBlockedFeedback(shortcut)) {
      this.showBlockedFeedback(shortcut);
    }
  }

  private shouldShowBlockedFeedback(shortcut: string): boolean {
    // Only show feedback for common user actions, not system-level shortcuts
    const feedbackShortcuts = [
      'Alt+Tab',
      'Alt+F4',
      'CommandOrControl+W',
      'CommandOrControl+Q',
      'CommandOrControl+T',
      'CommandOrControl+N',
      'Escape'
    ];

    return feedbackShortcuts.includes(shortcut);
  }

  private showBlockedFeedback(shortcut: string): void {
    // This could be enhanced to show a subtle visual indicator
    // For now, we'll just ensure the console logging is sufficient
    console.log(`🚫 Action blocked: ${shortcut}`);
    
    // Future enhancement: Could emit an event to show UI feedback
    // this.emit('shortcut-blocked', { shortcut, timestamp: Date.now() });
  }

  public getBlockedShortcutsCount(): number {
    return this.blockedShortcuts.length;
  }

  public isBlockingEnabled(): boolean {
    return this.isEnabled;
  }

  public getBlockedShortcuts(): string[] {
    return [...this.blockedShortcuts];
  }

  // Emergency method to disable all blocking (for development/debugging)
  public emergencyDisable(): void {
    console.log('Emergency disabling all keyboard blocking...');
    
    try {
      globalShortcut.unregisterAll();
      this.blockedShortcuts = [];
      this.originalHandlers.clear();
      this.isEnabled = false;
      
      console.log('Emergency disable completed');
    } catch (error) {
      console.error('Error during emergency disable:', error);
    }
  }

  // Method to temporarily allow specific shortcuts (for teacher override, etc.)
  public temporarilyAllowShortcuts(shortcuts: string[], durationMs: number = 10000): void {
    console.log(`Temporarily allowing shortcuts for ${durationMs}ms:`, shortcuts);

    const unregisteredShortcuts: string[] = [];

    // Unregister specified shortcuts
    shortcuts.forEach(shortcut => {
      if (this.blockedShortcuts.includes(shortcut)) {
        try {
          globalShortcut.unregister(shortcut);
          unregisteredShortcuts.push(shortcut);
          
          // Remove from blocked list temporarily
          const index = this.blockedShortcuts.indexOf(shortcut);
          if (index > -1) {
            this.blockedShortcuts.splice(index, 1);
          }
        } catch (error) {
          console.warn(`Error unregistering shortcut ${shortcut}:`, error.message);
        }
      }
    });

    // Re-register after duration
    setTimeout(() => {
      console.log('Re-registering temporarily allowed shortcuts...');
      
      unregisteredShortcuts.forEach(shortcut => {
        try {
          const success = globalShortcut.register(shortcut, () => {
            console.log(`Blocked shortcut (re-registered): ${shortcut}`);
            this.handleBlockedShortcut(shortcut);
          });

          if (success) {
            this.blockedShortcuts.push(shortcut);
          }
        } catch (error) {
          console.warn(`Error re-registering shortcut ${shortcut}:`, error.message);
        }
      });
    }, durationMs);
  }
}