import { app, BrowserWindow, dialog } from 'electron';
import * as path from 'path';
import ErrorIntegration from './errorIntegration';

// Enable garbage collection for memory recovery
app.commandLine.appendSwitch('--expose-gc');

class QuizLockMain {
  private mainWindow: Electron.BrowserWindow | null = null;
  private errorIntegration: ErrorIntegration;

  constructor() {
    this.errorIntegration = ErrorIntegration.getInstance();
    this.setupEventHandlers();
  }

  private setupEventHandlers() {
    // App event handlers
    app.whenReady().then(() => {
      this.createMainWindow();
    });

    app.on('window-all-closed', () => {
      if (process.platform !== 'darwin') {
        app.quit();
      }
    });

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        this.createMainWindow();
      }
    });

    // Error integration event handlers
    this.errorIntegration.on('window-recreated', (window) => {
      this.mainWindow = window;
      this.setupWindowErrorHandlers();
    });

    this.errorIntegration.on('safe-mode-entered', () => {
      console.log('Application entered safe mode');
    });

    this.errorIntegration.on('safe-mode-exited', () => {
      console.log('Application exited safe mode');
    });

    this.errorIntegration.on('emergency-exit-initiated', (reason) => {
      console.log(`Emergency exit initiated: ${reason}`);
    });

    // Handle specific recovery events
    this.errorIntegration.on('service-reconnect-attempt', () => {
      // Attempt to reconnect to Windows service
      console.log('Attempting to reconnect to QuizLock service...');
    });

    this.errorIntegration.on('database-recovery-started', () => {
      // Handle database recovery
      console.log('Starting database recovery process...');
    });

    this.errorIntegration.on('configuration-reset', (config) => {
      // Handle configuration reset
      console.log('Configuration has been reset:', config);
    });
  }

  private createMainWindow() {
    try {
      const mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        show: false,
        webPreferences: {
          nodeIntegration: false,
          contextIsolation: true,
          preload: path.join(__dirname, '../preload/index.js'),
          webSecurity: true
        },
        titleBarStyle: 'default',
        resizable: true,
        minimizable: true,
        maximizable: true,
        closable: true
      });

      this.mainWindow = mainWindow;

      // Initialize error recovery system with the main window
      this.errorIntegration.initialize(mainWindow);

      // Load the application
      this.loadApplication();

      // Show window when ready
      mainWindow.once('ready-to-show', () => {
        mainWindow.show();
      });

      // Setup error handlers
      this.setupWindowErrorHandlers();

    } catch (error) {
      // Report window creation error
      this.errorIntegration.reportError(
        error as Error, 
        'window_creation', 
        'critical',
        { context: 'main_window_creation' }
      );
    }
  }

  private loadApplication() {
    try {
      if (!this.mainWindow) return;

      // Load your main application interface
      // In a real application, this would load your React/Vue/HTML interface
      const indexPath = path.join(__dirname, '../renderer/index.html');
      this.mainWindow.loadFile(indexPath);

    } catch (error) {
      console.error('Failed to load application:', error);
      
      // Report loading error
      this.errorIntegration.reportError(
        error as Error,
        'app_loading',
        'high',
        { indexPath: path.join(__dirname, '../renderer/index.html') }
      );
    }
  }

  private setupWindowErrorHandlers() {
    if (!this.mainWindow) return;

    // Handle renderer crashes
    this.mainWindow.webContents.on('crashed', (event) => {
      console.error('Renderer process crashed');
      this.errorIntegration.reportError(
        new Error('Renderer process crashed'),
        'renderer',
        'critical',
        { processId: this.mainWindow?.webContents.getOSProcessId() }
      );
    });

    // Handle renderer becoming unresponsive
    this.mainWindow.webContents.on('unresponsive', () => {
      console.warn('Renderer process became unresponsive');
      this.errorIntegration.reportError(
        new Error('Renderer process unresponsive'),
        'renderer',
        'high',
        { processId: this.mainWindow?.webContents.getOSProcessId() }
      );
    });

    // Handle renderer becoming responsive again
    this.mainWindow.webContents.on('responsive', () => {
      console.log('Renderer process is responsive again');
    });

    // Handle navigation errors
    this.mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL) => {
      console.error('Failed to load URL:', errorDescription);
      this.errorIntegration.reportError(
        new Error(`Failed to load URL: ${errorDescription}`),
        'navigation',
        'medium',
        { errorCode, validatedURL }
      );
    });

    // Handle certificate errors
    this.mainWindow.webContents.on('certificate-error', (event, url, error, certificate, callback) => {
      console.error('Certificate error:', error);
      this.errorIntegration.reportError(
        new Error(`Certificate error: ${error}`),
        'security',
        'medium',
        { url, certificate }
      );
      callback(false); // Reject the certificate
    });
  }

  // Example methods showing how to use error recovery in your application

  // Simulate a memory leak for testing
  public simulateMemoryLeak() {
    const largeArray: any[] = [];
    for (let i = 0; i < 1000000; i++) {
      largeArray.push({ data: new Array(1000).fill('test') });
    }
    
    // This will trigger memory recovery
    this.errorIntegration.reportError(
      new Error('Memory usage exceeded threshold'),
      'memory',
      'medium',
      { arraySize: largeArray.length }
    );
  }

  // Simulate a service connection failure
  public simulateServiceFailure() {
    this.errorIntegration.reportError(
      new Error('ECONNREFUSED: Connection refused'),
      'agent_communication',
      'high',
      { service: 'QuizLockService', port: 8080 }
    );
  }

  // Simulate a database error
  public simulateDatabaseError() {
    this.errorIntegration.reportError(
      new Error('SQLITE_CORRUPT: Database disk image is malformed'),
      'database',
      'critical',
      { database: 'quizlock.db', table: 'sessions' }
    );
  }

  // Example of manual error reporting from your application code
  public handleApplicationError(error: Error, context: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium') {
    return this.errorIntegration.reportError(error, context, severity);
  }

  // Get system health status
  public getSystemHealth() {
    return {
      healthy: this.errorIntegration.getSystemHealth(),
      stats: this.errorIntegration.getErrorStats(),
      safeMode: this.errorIntegration.isSafeMode()
    };
  }

  // Export error logs for debugging
  public async exportErrorLogs(): Promise<string | null> {
    return await this.errorIntegration.exportErrorLogs();
  }

  // Admin function to clear error history
  public clearErrorHistory(): void {
    this.errorIntegration.clearErrorHistory();
  }

  // Exit safe mode (if in safe mode)
  public exitSafeMode(): void {
    this.errorIntegration.exitSafeMode();
  }
}

// Initialize the application
const quizLockMain = new QuizLockMain();

// Handle process termination gracefully
process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully...');
  app.quit();
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  app.quit();
});

export { quizLockMain };
export default QuizLockMain;