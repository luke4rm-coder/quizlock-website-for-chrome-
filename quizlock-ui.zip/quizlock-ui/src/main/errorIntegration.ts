import { app, BrowserWindow, ipcMain } from 'electron';
import { EventEmitter } from 'events';
import ErrorRecoverySystem from './errorRecovery';
import * as path from 'path';
import * as fs from 'fs';

interface AppState {
  mainWindow: Electron.BrowserWindow | null;
  gateMode: boolean;
  serviceConnected: boolean;
  configPath: string;
  safeMode: boolean;
}

export class ErrorIntegration extends EventEmitter {
  private static instance: ErrorIntegration;
  private errorRecovery: ErrorRecoverySystem;
  private appState: AppState;
  private originalConfig: any = null;

  private constructor() {
    super();
    this.errorRecovery = ErrorRecoverySystem.getInstance();
    this.appState = {
      mainWindow: null,
      gateMode: false,
      serviceConnected: false,
      configPath: path.join(process.cwd(), 'config', 'app.json'),
      safeMode: false
    };

    this.setupErrorRecoveryHandlers();
    this.setupIPCHandlers();
  }

  public static getInstance(): ErrorIntegration {
    if (!ErrorIntegration.instance) {
      ErrorIntegration.instance = new ErrorIntegration();
    }
    return ErrorIntegration.instance;
  }

  public initialize(mainWindow: Electron.BrowserWindow) {
    this.appState.mainWindow = mainWindow;
    this.loadConfiguration();
    
    console.log('Error recovery system initialized');
  }

  private setupErrorRecoveryHandlers() {
    // Handle recreation of windows
    this.errorRecovery.on('recreate-windows', (options) => {
      this.recreateMainWindow(options);
    });

    // Handle service reconnection
    this.errorRecovery.on('reconnect-service', () => {
      this.reconnectToService();
    });

    // Handle service connection testing
    this.errorRecovery.on('test-service-connection', () => {
      this.testServiceConnection();
    });

    // Handle database recovery
    this.errorRecovery.on('recover-database', () => {
      this.recoverDatabase();
    });

    // Handle configuration reset
    this.errorRecovery.on('reset-configuration', (options) => {
      this.resetConfiguration(options);
    });

    // Handle safe mode entry
    this.errorRecovery.on('enter-safe-mode', (options) => {
      this.enterSafeMode(options);
    });

    // Handle cache clearing
    this.errorRecovery.on('clear-temp-files', () => {
      this.clearTemporaryFiles();
    });

    // Handle emergency exit
    this.errorRecovery.on('emergency-exit', (reason) => {
      this.performEmergencyExit(reason);
    });

    // Handle system health changes
    this.errorRecovery.on('system-health-changed', (healthy) => {
      this.notifyHealthChange(healthy);
    });

    // Handle error notifications
    this.errorRecovery.on('error-handled', (data) => {
      this.notifyErrorHandled(data);
    });
  }

  private setupIPCHandlers() {
    // Allow renderer to report errors
    ipcMain.handle('report-error', async (event, errorData) => {
      const error = new Error(errorData.message);
      error.stack = errorData.stack;
      return await this.errorRecovery.handleError(
        error, 
        errorData.component || 'renderer', 
        errorData.severity || 'medium',
        errorData.userData
      );
    });

    // Allow renderer to get system health
    ipcMain.handle('get-system-health', () => {
      return {
        healthy: this.errorRecovery.getSystemHealth(),
        stats: this.errorRecovery.getErrorStats(),
        safeMode: this.appState.safeMode
      };
    });

    // Allow renderer to clear error history (admin only)
    ipcMain.handle('clear-error-history', () => {
      this.errorRecovery.clearErrorHistory();
      return true;
    });

    // Allow renderer to export error logs
    ipcMain.handle('export-error-logs', async () => {
      try {
        return await this.errorRecovery.exportErrorLogs();
      } catch (error) {
        console.error('Failed to export error logs:', error);
        return null;
      }
    });
  }

  private recreateMainWindow(options: any = {}) {
    try {
      console.log('Recreating main window...');

      // Close existing window
      if (this.appState.mainWindow && !this.appState.mainWindow.isDestroyed()) {
        this.appState.mainWindow.close();
      }

      // Create new window with safe defaults
      const windowOptions: Electron.BrowserWindowConstructorOptions = {
        width: options.safeMode ? 800 : 1200,
        height: options.safeMode ? 600 : 800,
        show: false,
        webPreferences: {
          nodeIntegration: false,
          contextIsolation: true,
          preload: path.join(__dirname, '../preload/index.js'),
          webSecurity: true,
          allowRunningInsecureContent: false
        },
        titleBarStyle: 'default',
        resizable: !options.safeMode,
        minimizable: true,
        maximizable: !options.safeMode,
        closable: true
      };

      this.appState.mainWindow = new BrowserWindow(windowOptions);

      // Load safe URL
      if (options.safeMode) {
        this.loadSafeModeInterface();
      } else {
        this.loadMainInterface();
      }

      // Show window when ready
      this.appState.mainWindow.once('ready-to-show', () => {
        this.appState.mainWindow?.show();
      });

      // Handle window errors
      this.appState.mainWindow.webContents.on('crashed', (event) => {
        const error = new Error('Renderer process crashed');
        this.errorRecovery.handleError(error, 'renderer', 'critical');
      });

      this.appState.mainWindow.webContents.on('unresponsive', () => {
        const error = new Error('Renderer process unresponsive');
        this.errorRecovery.handleError(error, 'renderer', 'high');
      });

      this.appState.mainWindow.webContents.on('responsive', () => {
        console.log('Renderer process responsive again');
      });

      this.emit('window-recreated', this.appState.mainWindow);

    } catch (error) {
      console.error('Failed to recreate main window:', error);
      this.errorRecovery.handleError(error, 'window_creation', 'critical');
    }
  }

  private loadMainInterface() {
    try {
      if (!this.appState.mainWindow) return;

      // Load the main application interface
      const indexPath = path.join(__dirname, '../renderer/index.html');
      this.appState.mainWindow.loadFile(indexPath);

    } catch (error) {
      console.error('Failed to load main interface:', error);
      this.loadSafeModeInterface();
    }
  }

  private loadSafeModeInterface() {
    try {
      if (!this.appState.mainWindow) return;

      // Create a simple safe mode HTML interface
      const safeHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>QuizLock - Safe Mode</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              background: #f8f9fa;
              margin: 0;
              padding: 40px;
              text-align: center;
            }
            .container {
              max-width: 600px;
              margin: 0 auto;
              background: white;
              padding: 40px;
              border-radius: 8px;
              box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .warning-icon {
              font-size: 64px;
              margin-bottom: 20px;
            }
            h1 {
              color: #dc3545;
              margin-bottom: 15px;
            }
            .status {
              background: #fff3cd;
              border: 1px solid #ffeaa7;
              color: #856404;
              padding: 15px;
              border-radius: 4px;
              margin: 20px 0;
            }
            button {
              background: #007bff;
              color: white;
              border: none;
              padding: 10px 20px;
              border-radius: 4px;
              margin: 5px;
              cursor: pointer;
            }
            button:hover {
              background: #0056b3;
            }
            .exit-btn {
              background: #dc3545;
            }
            .exit-btn:hover {
              background: #c82333;
            }
            .restart-btn {
              background: #28a745;
            }
            .restart-btn:hover {
              background: #1e7e34;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="warning-icon">⚠️</div>
            <h1>QuizLock Safe Mode</h1>
            <p>QuizLock is running in safe mode due to system errors. Some features are disabled for stability.</p>
            
            <div class="status">
              <strong>Safe Mode Active</strong><br>
              Advanced features like gate mode and keyboard blocking are temporarily disabled.
            </div>

            <div>
              <button onclick="restartNormal()">Restart Normal Mode</button>
              <button class="restart-btn" onclick="restartApp()">Restart Application</button>
              <button class="exit-btn" onclick="exitApp()">Exit Application</button>
            </div>

            <p style="margin-top: 30px; font-size: 14px; color: #666;">
              If this problem persists, contact your IT administrator.
            </p>
          </div>

          <script>
            function restartNormal() {
              window.electronAPI.exitSafeMode();
            }
            
            function restartApp() {
              window.electronAPI.restartApplication();
            }
            
            function exitApp() {
              window.electronAPI.exitApplication();
            }
          </script>
        </body>
        </html>
      `;

      this.appState.mainWindow.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(safeHtml)}`);

    } catch (error) {
      console.error('Failed to load safe mode interface:', error);
    }
  }

  private reconnectToService() {
    try {
      console.log('Attempting to reconnect to service...');
      
      // Emit reconnection attempt
      this.emit('service-reconnect-attempt');
      
      // In a real implementation, this would attempt to reconnect to your Windows service
      // For now, we'll simulate the reconnection
      setTimeout(() => {
        this.appState.serviceConnected = true;
        this.emit('service-reconnected');
        console.log('Service reconnection successful');
      }, 2000);

    } catch (error) {
      console.error('Service reconnection failed:', error);
      this.appState.serviceConnected = false;
      this.emit('service-reconnect-failed', error);
    }
  }

  private testServiceConnection() {
    try {
      // Test if the service is responding
      // In a real implementation, this would ping your service
      this.emit('service-connection-test', this.appState.serviceConnected);
      
    } catch (error) {
      console.error('Service connection test failed:', error);
      this.appState.serviceConnected = false;
    }
  }

  private recoverDatabase() {
    try {
      console.log('Attempting database recovery...');
      
      // In a real implementation, this would:
      // 1. Create a backup of the corrupted database
      // 2. Attempt to repair using SQLite tools
      // 3. If repair fails, restore from backup
      // 4. If no backup, recreate with default schema
      
      this.emit('database-recovery-started');
      
      // Simulate database recovery
      setTimeout(() => {
        this.emit('database-recovery-completed', true);
        console.log('Database recovery completed');
      }, 3000);

    } catch (error) {
      console.error('Database recovery failed:', error);
      this.emit('database-recovery-completed', false);
    }
  }

  private loadConfiguration() {
    try {
      if (fs.existsSync(this.appState.configPath)) {
        const configData = fs.readFileSync(this.appState.configPath, 'utf8');
        this.originalConfig = JSON.parse(configData);
      } else {
        this.originalConfig = this.getDefaultConfiguration();
      }
    } catch (error) {
      console.error('Failed to load configuration:', error);
      this.originalConfig = this.getDefaultConfiguration();
    }
  }

  private resetConfiguration(options: any = {}) {
    try {
      console.log('Resetting configuration to defaults...');
      
      // Backup current config if not emergency
      if (!options.emergency && this.originalConfig) {
        const backupPath = this.appState.configPath + '.backup';
        fs.writeFileSync(backupPath, JSON.stringify(this.originalConfig, null, 2));
      }

      // Create default configuration
      const defaultConfig = this.getDefaultConfiguration();
      
      if (options.safeMode) {
        // Apply safe mode overrides
        defaultConfig.gateMode = false;
        defaultConfig.keyboardBlocking = false;
        defaultConfig.monitoring = false;
        defaultConfig.safeMode = true;
      }

      // Ensure config directory exists
      const configDir = path.dirname(this.appState.configPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }

      // Write default configuration
      fs.writeFileSync(this.appState.configPath, JSON.stringify(defaultConfig, null, 2));
      
      this.emit('configuration-reset', defaultConfig);
      console.log('Configuration reset completed');

    } catch (error) {
      console.error('Failed to reset configuration:', error);
      this.errorRecovery.handleError(error, 'config_reset', 'high');
    }
  }

  private getDefaultConfiguration() {
    return {
      version: '1.0.0',
      gateMode: false,
      keyboardBlocking: false,
      monitoring: true,
      safeMode: false,
      ui: {
        theme: 'light',
        notifications: true,
        soundEnabled: false
      },
      security: {
        adminRequired: true,
        sessionTimeout: 3600000, // 1 hour
        maxLoginAttempts: 3
      },
      logging: {
        level: 'info',
        maxFileSize: 10485760, // 10MB
        maxFiles: 5
      },
      recovery: {
        autoRecovery: true,
        maxRetries: 3,
        safeMode: true
      }
    };
  }

  private enterSafeMode(options: any = {}) {
    try {
      console.log('Entering safe mode...');
      
      this.appState.safeMode = true;
      this.appState.gateMode = false;

      // Disable potentially problematic features
      if (options.disableGateMode) {
        this.emit('disable-gate-mode');
      }
      
      if (options.disableKeyboardBlocking) {
        this.emit('disable-keyboard-blocking');
      }
      
      if (options.disableMonitoring) {
        this.emit('disable-monitoring');
      }

      // Update configuration
      this.resetConfiguration({ safeMode: true });

      // Recreate windows in safe mode
      this.recreateMainWindow({ safeMode: true });

      this.emit('safe-mode-entered');

    } catch (error) {
      console.error('Failed to enter safe mode:', error);
    }
  }

  private clearTemporaryFiles() {
    try {
      console.log('Clearing temporary files...');
      
      const tempDirs = [
        path.join(process.cwd(), 'temp'),
        path.join(process.cwd(), 'cache'),
        path.join(process.cwd(), 'logs', 'temp')
      ];

      for (const tempDir of tempDirs) {
        if (fs.existsSync(tempDir)) {
          const files = fs.readdirSync(tempDir);
          for (const file of files) {
            const filePath = path.join(tempDir, file);
            try {
              const stats = fs.statSync(filePath);
              if (stats.isFile()) {
                fs.unlinkSync(filePath);
              }
            } catch (error) {
              console.warn(`Failed to delete temp file: ${filePath}`);
            }
          }
        }
      }

      this.emit('temp-files-cleared');

    } catch (error) {
      console.error('Failed to clear temporary files:', error);
    }
  }

  private performEmergencyExit(reason: string) {
    try {
      console.log(`Performing emergency exit: ${reason}`);
      
      // Log the emergency exit
      const logEntry = {
        timestamp: new Date().toISOString(),
        type: 'emergency_exit',
        reason,
        appState: this.appState
      };

      const emergencyLogPath = path.join(process.cwd(), 'logs', 'emergency.log');
      fs.appendFileSync(emergencyLogPath, JSON.stringify(logEntry) + '\n');

      // Emit emergency exit event
      this.emit('emergency-exit-initiated', reason);

      // Force exit after a brief delay
      setTimeout(() => {
        process.exit(1);
      }, 2000);

    } catch (error) {
      console.error('Emergency exit failed:', error);
      process.exit(1);
    }
  }

  private notifyHealthChange(healthy: boolean) {
    // Send health change notification to renderer
    if (this.appState.mainWindow && !this.appState.mainWindow.isDestroyed()) {
      this.appState.mainWindow.webContents.send('system-health-changed', healthy);
    }

    this.emit('health-status-changed', healthy);
  }

  private notifyErrorHandled(data: any) {
    // Send error notification to renderer
    if (this.appState.mainWindow && !this.appState.mainWindow.isDestroyed()) {
      this.appState.mainWindow.webContents.send('error-handled', {
        timestamp: data.context.timestamp,
        component: data.context.component,
        severity: data.context.severity,
        recovered: data.recovered
      });
    }

    this.emit('error-notification', data);
  }

  // Public API methods
  public reportError(error: Error, component: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium', userData?: any): Promise<boolean> {
    return this.errorRecovery.handleError(error, component, severity, userData);
  }

  public getSystemHealth(): boolean {
    return this.errorRecovery.getSystemHealth();
  }

  public getErrorStats() {
    return this.errorRecovery.getErrorStats();
  }

  public isSafeMode(): boolean {
    return this.appState.safeMode;
  }

  public exitSafeMode() {
    if (this.appState.safeMode) {
      this.appState.safeMode = false;
      this.resetConfiguration({ safeMode: false });
      this.recreateMainWindow({ safeMode: false });
      this.emit('safe-mode-exited');
    }
  }

  public async exportErrorLogs(): Promise<string | null> {
    try {
      return await this.errorRecovery.exportErrorLogs();
    } catch (error) {
      console.error('Failed to export error logs:', error);
      return null;
    }
  }

  public clearErrorHistory(): void {
    this.errorRecovery.clearErrorHistory();
  }
}

export default ErrorIntegration;