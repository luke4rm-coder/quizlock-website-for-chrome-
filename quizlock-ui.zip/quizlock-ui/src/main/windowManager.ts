import { BrowserWindow, screen } from 'electron';
import * as path from 'path';

export class WindowManager {
  private gateWindows: BrowserWindow[] = [];
  private displays: Electron.Display[] = [];

  constructor() {
    this.updateDisplays();
    
    // Listen for display changes
    screen.on('display-added', () => {
      this.updateDisplays();
      if (this.gateWindows.length > 0) {
        this.recreateFullScreenWindows();
      }
    });

    screen.on('display-removed', () => {
      this.updateDisplays();
      if (this.gateWindows.length > 0) {
        this.recreateFullScreenWindows();
      }
    });

    screen.on('display-metrics-changed', () => {
      this.updateDisplays();
      if (this.gateWindows.length > 0) {
        this.adjustWindowsForDisplayChanges();
      }
    });
  }

  private updateDisplays() {
    this.displays = screen.getAllDisplays();
    console.log(`Detected ${this.displays.length} display(s):`, 
      this.displays.map(d => `${d.bounds.width}x${d.bounds.height} at ${d.bounds.x},${d.bounds.y}`)
    );
  }

  public createFullScreenWindows() {
    console.log('Creating full-screen gate windows...');
    
    this.closeFullScreenWindows(); // Clean up any existing windows
    
    this.displays.forEach((display, index) => {
      const window = this.createGateWindow(display, index === 0);
      this.gateWindows.push(window);
    });

    console.log(`Created ${this.gateWindows.length} gate windows`);
  }

  private createGateWindow(display: Electron.Display, isPrimary: boolean): BrowserWindow {
    const { bounds, scaleFactor } = display;
    
    const window = new BrowserWindow({
      x: bounds.x,
      y: bounds.y,
      width: bounds.width,
      height: bounds.height,
      fullscreen: true,
      alwaysOnTop: true,
      frame: false,
      resizable: false,
      minimizable: false,
      maximizable: false,
      closable: false,
      skipTaskbar: true,
      kiosk: true,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        preload: path.join(__dirname, 'preload.js'),
        // Disable web security for local content
        webSecurity: false,
        // Handle high DPI displays
        zoomFactor: 1 / scaleFactor
      },
      show: false,
      title: 'QuizLock Gate'
    });

    // Load the gate UI
    const isDev = process.env.NODE_ENV === 'development';
    const rendererPath = isPrimary ? '?mode=gate&primary=true' : '?mode=gate&primary=false';
    
    if (isDev) {
      window.loadURL(`http://localhost:3000/${rendererPath}`);
    } else {
      window.loadFile(path.join(__dirname, '../renderer/index.html'), {
        query: { mode: 'gate', primary: isPrimary.toString() }
      });
    }

    // Set up window event handlers
    this.setupWindowEventHandlers(window, isPrimary);

    // Show window once ready
    window.once('ready-to-show', () => {
      window.show();
      window.focus();
      
      // Ensure window stays on top and covers everything
      window.setAlwaysOnTop(true, 'screen-saver', 1);
      window.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
      
      console.log(`Gate window ready on display ${bounds.x},${bounds.y} (${bounds.width}x${bounds.height})`);
    });

    return window;
  }

  private setupWindowEventHandlers(window: BrowserWindow, isPrimary: boolean) {
    // Prevent window closure
    window.on('close', (event) => {
      console.log('Gate window close attempt prevented');
      event.preventDefault();
    });

    // Handle window focus loss
    window.on('blur', () => {
      console.log('Gate window lost focus, refocusing...');
      setTimeout(() => {
        if (!window.isDestroyed()) {
          window.focus();
        }
      }, 100);
    });

    // Handle minimize attempts
    window.on('minimize', (event) => {
      console.log('Gate window minimize attempt prevented');
      event.preventDefault();
      window.restore();
      window.focus();
    });

    // Handle hide attempts
    window.on('hide', () => {
      console.log('Gate window hide attempt, showing...');
      if (!window.isDestroyed()) {
        window.show();
        window.focus();
      }
    });

    // Handle move attempts
    window.on('moved', () => {
      console.log('Gate window moved, restoring position...');
      const display = screen.getDisplayNearestPoint(window.getBounds());
      if (display) {
        window.setBounds(display.bounds, false);
      }
    });

    // Handle resize attempts
    window.on('resized', () => {
      console.log('Gate window resized, restoring full-screen...');
      const display = screen.getDisplayNearestPoint(window.getBounds());
      if (display) {
        window.setBounds(display.bounds, false);
      }
    });

    // Handle right-click context menu
    window.webContents.on('context-menu', (event) => {
      event.preventDefault();
    });

    // Prevent navigation
    window.webContents.on('will-navigate', (event, navigationUrl) => {
      const currentUrl = window.webContents.getURL();
      if (navigationUrl !== currentUrl) {
        console.log('Navigation attempt prevented:', navigationUrl);
        event.preventDefault();
      }
    });

    // Handle new window attempts
    window.webContents.setWindowOpenHandler(() => {
      console.log('New window attempt prevented');
      return { action: 'deny' };
    });

    // Block dev tools in production
    if (process.env.NODE_ENV !== 'development') {
      window.webContents.on('before-input-event', (event, input) => {
        if (input.key === 'F12' || (input.control && input.shift && input.key === 'I')) {
          event.preventDefault();
        }
      });
    }
  }

  public closeFullScreenWindows() {
    console.log('Closing full-screen gate windows...');
    
    this.gateWindows.forEach((window) => {
      if (!window.isDestroyed()) {
        // Temporarily allow closing
        window.removeAllListeners('close');
        window.closable = true;
        window.close();
      }
    });
    
    this.gateWindows = [];
  }

  public ensureFullScreenCoverage() {
    console.log('Ensuring full-screen coverage...');
    
    // Check if all displays are covered
    const coveredDisplays = new Set();
    
    this.gateWindows.forEach((window) => {
      if (!window.isDestroyed()) {
        const bounds = window.getBounds();
        const display = screen.getDisplayNearestPoint(bounds);
        coveredDisplays.add(display.id);
        
        // Ensure window covers entire display
        if (!this.boundsEqual(bounds, display.bounds)) {
          window.setBounds(display.bounds, false);
        }
        
        // Ensure window properties
        if (!window.isAlwaysOnTop()) {
          window.setAlwaysOnTop(true, 'screen-saver', 1);
        }
        
        if (!window.isVisible()) {
          window.show();
          window.focus();
        }
      }
    });

    // Create windows for uncovered displays
    this.displays.forEach((display, index) => {
      if (!coveredDisplays.has(display.id)) {
        console.log(`Creating window for uncovered display ${display.id}`);
        const window = this.createGateWindow(display, index === 0);
        this.gateWindows.push(window);
      }
    });
  }

  private recreateFullScreenWindows() {
    console.log('Recreating full-screen windows due to display change...');
    this.closeFullScreenWindows();
    setTimeout(() => {
      this.createFullScreenWindows();
    }, 500);
  }

  private adjustWindowsForDisplayChanges() {
    console.log('Adjusting windows for display metrics changes...');
    
    this.gateWindows.forEach((window) => {
      if (!window.isDestroyed()) {
        const bounds = window.getBounds();
        const display = screen.getDisplayNearestPoint(bounds);
        
        // Update window bounds to match display
        window.setBounds(display.bounds, false);
        
        // Update zoom factor if DPI changed
        if (display.scaleFactor !== 1) {
          window.webContents.setZoomFactor(1 / display.scaleFactor);
        }
      }
    });
  }

  private boundsEqual(bounds1: Electron.Rectangle, bounds2: Electron.Rectangle): boolean {
    return bounds1.x === bounds2.x &&
           bounds1.y === bounds2.y &&
           bounds1.width === bounds2.width &&
           bounds1.height === bounds2.height;
  }

  public getPrimaryWindow(): BrowserWindow | null {
    return this.gateWindows.length > 0 ? this.gateWindows[0] : null;
  }

  public getAllGateWindows(): BrowserWindow[] {
    return this.gateWindows.filter(w => !w.isDestroyed());
  }

  public getWindowCount(): number {
    return this.gateWindows.filter(w => !w.isDestroyed()).length;
  }

  public forceCloseAllWindows() {
    console.log('Force closing all gate windows...');
    
    this.gateWindows.forEach((window) => {
      if (!window.isDestroyed()) {
        window.removeAllListeners();
        window.destroy();
      }
    });
    
    this.gateWindows = [];
  }
}