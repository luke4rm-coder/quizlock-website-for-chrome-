import { app, dialog, BrowserWindow } from 'electron';
import { exec } from 'child_process';
import * as fs from 'fs/promises';
import * as path from 'path';

export class EmergencySystem {
  private static instance: EmergencySystem;
  private emergencyExitCodes = ['emergency2024', 'admin911', 'unlock123'];
  private isEmergencyMode = false;
  private emergencyLogPath: string;

  private constructor() {
    this.emergencyLogPath = path.join(
      process.env.LOCALAPPDATA || '',
      'QuizLock',
      'emergency.log'
    );
    this.setupEmergencyHandlers();
  }

  public static getInstance(): EmergencySystem {
    if (!EmergencySystem.instance) {
      EmergencySystem.instance = new EmergencySystem();
    }
    return EmergencySystem.instance;
  }

  private setupEmergencyHandlers() {
    // Handle uncaught exceptions
    process.on('uncaughtException', async (error) => {
      console.error('Uncaught exception:', error);
      await this.logEmergencyEvent('UNCAUGHT_EXCEPTION', error.message);
      
      if (this.isInGateMode()) {
        await this.handleCriticalFailure('Uncaught exception in gate mode');
      }
    });

    // Handle unhandled promise rejections
    process.on('unhandledRejection', async (reason, promise) => {
      console.error('Unhandled rejection at:', promise, 'reason:', reason);
      await this.logEmergencyEvent('UNHANDLED_REJECTION', String(reason));
      
      if (this.isInGateMode()) {
        await this.handleCriticalFailure('Unhandled promise rejection in gate mode');
      }
    });

    // Handle system signals
    process.on('SIGTERM', async () => {
      console.log('SIGTERM received');
      await this.logEmergencyEvent('SIGTERM', 'System termination signal received');
      
      if (this.isInGateMode()) {
        await this.handleGracefulShutdown();
      }
    });

    process.on('SIGINT', async () => {
      console.log('SIGINT received');
      await this.logEmergencyEvent('SIGINT', 'Interrupt signal received');
      
      if (this.isInGateMode()) {
        await this.handleGracefulShutdown();
      }
    });
  }

  public async requestEmergencyExit(reason: string = 'User request'): Promise<boolean> {
    try {
      console.log('Emergency exit requested:', reason);
      await this.logEmergencyEvent('EMERGENCY_EXIT_REQUEST', reason);

      // Show emergency exit dialog
      const result = await dialog.showMessageBox({
        type: 'warning',
        title: 'Emergency Exit',
        message: 'Emergency exit requested. This will bypass the learning gate.',
        detail: 'Enter the emergency code to proceed. This action will be logged.',
        buttons: ['Cancel', 'Enter Code'],
        defaultId: 0,
        cancelId: 0
      });

      if (result.response !== 1) {
        await this.logEmergencyEvent('EMERGENCY_EXIT_CANCELLED', 'User cancelled emergency exit');
        return false;
      }

      // Get emergency code
      const code = await this.promptForEmergencyCode();
      if (!code) {
        await this.logEmergencyEvent('EMERGENCY_EXIT_NO_CODE', 'No emergency code provided');
        return false;
      }

      // Validate emergency code (this should use AgentCommunication in real implementation)
      const isValidCode = this.validateEmergencyCode(code);
      
      if (!isValidCode) {
        await this.logEmergencyEvent('EMERGENCY_EXIT_INVALID_CODE', `Invalid code attempted: ${code.substring(0, 3)}***`);
        
        dialog.showErrorBox(
          'Access Denied',
          'Invalid emergency code. This attempt has been logged.'
        );
        return false;
      }

      // Execute emergency exit
      await this.executeEmergencyExit(reason);
      return true;

    } catch (error) {
      console.error('Error during emergency exit:', error);
      await this.logEmergencyEvent('EMERGENCY_EXIT_ERROR', String(error));
      
      // Force exit as last resort
      await this.forceExit();
      return true;
    }
  }

  public async handleCriticalFailure(reason: string): Promise<void> {
    try {
      console.error('Critical failure detected:', reason);
      await this.logEmergencyEvent('CRITICAL_FAILURE', reason);

      this.isEmergencyMode = true;

      // Show error dialog
      const result = await dialog.showMessageBox({
        type: 'error',
        title: 'QuizLock Critical Error',
        message: 'A critical error has occurred that prevents normal operation.',
        detail: `Error: ${reason}\n\nThe system will attempt automatic recovery. If this continues, contact your system administrator.`,
        buttons: ['Attempt Recovery', 'Emergency Exit', 'Force Quit'],
        defaultId: 0
      });

      switch (result.response) {
        case 0: // Attempt Recovery
          await this.attemptRecovery();
          break;
        case 1: // Emergency Exit
          await this.executeEmergencyExit('Critical failure');
          break;
        case 2: // Force Quit
          await this.forceExit();
          break;
      }

    } catch (error) {
      console.error('Error handling critical failure:', error);
      await this.forceExit();
    }
  }

  public async checkSystemHealth(): Promise<{ healthy: boolean; issues: string[] }> {
    const issues: string[] = [];

    try {
      // Check if gate windows are responsive
      const windows = BrowserWindow.getAllWindows();
      for (const window of windows) {
        if (!window.isDestroyed()) {
          try {
            // Test window responsiveness
            await window.webContents.executeJavaScript('true');
          } catch (error) {
            issues.push(`Window ${window.id} is not responsive`);
          }
        }
      }

      // Check available memory
      const memoryUsage = process.memoryUsage();
      const maxMemory = 500 * 1024 * 1024; // 500MB limit
      if (memoryUsage.heapUsed > maxMemory) {
        issues.push(`High memory usage: ${Math.round(memoryUsage.heapUsed / 1024 / 1024)}MB`);
      }

      // Check if emergency log is writable
      try {
        await this.logEmergencyEvent('HEALTH_CHECK', 'System health check performed');
      } catch (error) {
        issues.push('Cannot write to emergency log');
      }

      return {
        healthy: issues.length === 0,
        issues
      };

    } catch (error) {
      issues.push(`Health check failed: ${error}`);
      return { healthy: false, issues };
    }
  }

  public async scheduleHealthChecks(): Promise<void> {
    // Run health checks every 30 seconds
    setInterval(async () => {
      if (this.isInGateMode()) {
        const health = await this.checkSystemHealth();
        if (!health.healthy) {
          console.warn('System health issues detected:', health.issues);
          await this.logEmergencyEvent('HEALTH_WARNING', health.issues.join('; '));

          // If critical issues, offer recovery
          if (health.issues.some(issue => 
            issue.includes('not responsive') || 
            issue.includes('memory usage')
          )) {
            await this.offerAutomaticRecovery(health.issues);
          }
        }
      }
    }, 30000);
  }

  public registerGlobalEmergencyShortcuts(): void {
    // Emergency shortcuts that work even when gate is active
    const { globalShortcut } = require('electron');

    // Ctrl+Alt+Shift+E - Emergency exit (development only)
    if (process.env.NODE_ENV === 'development') {
      globalShortcut.register('CommandOrControl+Alt+Shift+E', async () => {
        console.log('Emergency shortcut activated');
        await this.requestEmergencyExit('Emergency shortcut');
      });
    }

    // Ctrl+Alt+Shift+R - Recovery mode
    globalShortcut.register('CommandOrControl+Alt+Shift+R', async () => {
      console.log('Recovery shortcut activated');
      await this.attemptRecovery();
    });

    // Triple Ctrl press detection for emergency
    let ctrlPressCount = 0;
    let ctrlTimer: NodeJS.Timeout;

    const resetCtrlCount = () => {
      ctrlPressCount = 0;
      if (ctrlTimer) clearTimeout(ctrlTimer);
    };

    // This would need to be implemented with a low-level keyboard hook
    // For now, we register a visible shortcut
    globalShortcut.register('CommandOrControl+CommandOrControl+CommandOrControl', async () => {
      await this.requestEmergencyExit('Triple Ctrl emergency');
    });
  }

  private async executeEmergencyExit(reason: string): Promise<void> {
    try {
      console.log('Executing emergency exit:', reason);
      await this.logEmergencyEvent('EMERGENCY_EXIT_EXECUTED', reason);

      this.isEmergencyMode = true;

      // Close all gate windows
      const windows = BrowserWindow.getAllWindows();
      for (const window of windows) {
        if (!window.isDestroyed()) {
          window.removeAllListeners();
          window.closable = true;
          window.destroy();
        }
      }

      // Unregister all shortcuts
      const { globalShortcut } = require('electron');
      globalShortcut.unregisterAll();

      // Show confirmation
      dialog.showMessageBox({
        type: 'info',
        title: 'Emergency Exit Complete',
        message: 'Emergency exit completed successfully.',
        detail: 'The learning gate has been disabled. This action has been logged for review.',
        buttons: ['OK']
      });

      // Quit application
      app.quit();

    } catch (error) {
      console.error('Error executing emergency exit:', error);
      await this.forceExit();
    }
  }

  private async attemptRecovery(): Promise<void> {
    try {
      console.log('Attempting system recovery...');
      await this.logEmergencyEvent('RECOVERY_ATTEMPT', 'Automatic recovery initiated');

      // Close unresponsive windows
      const windows = BrowserWindow.getAllWindows();
      for (const window of windows) {
        if (!window.isDestroyed()) {
          try {
            await window.webContents.executeJavaScript('true');
          } catch (error) {
            console.log(`Closing unresponsive window ${window.id}`);
            window.destroy();
          }
        }
      }

      // Force garbage collection if available
      if (global.gc) {
        global.gc();
      }

      // Restart gate if needed
      // This would integrate with the main QuizLock application
      
      await this.logEmergencyEvent('RECOVERY_SUCCESS', 'System recovery completed');
      
      dialog.showMessageBox({
        type: 'info',
        title: 'Recovery Complete',
        message: 'System recovery completed successfully.',
        detail: 'The system has been restored to a stable state.',
        buttons: ['OK']
      });

    } catch (error) {
      console.error('Recovery failed:', error);
      await this.logEmergencyEvent('RECOVERY_FAILED', String(error));
      
      dialog.showErrorBox(
        'Recovery Failed',
        'Automatic recovery failed. Emergency exit may be required.'
      );
    }
  }

  private async forceExit(): Promise<void> {
    try {
      console.log('Executing force exit...');
      await this.logEmergencyEvent('FORCE_EXIT', 'Force exit executed');

      // Destroy all windows immediately
      BrowserWindow.getAllWindows().forEach(window => {
        if (!window.isDestroyed()) {
          window.destroy();
        }
      });

      // Unregister shortcuts
      const { globalShortcut } = require('electron');
      globalShortcut.unregisterAll();

    } catch (error) {
      console.error('Error during force exit:', error);
    } finally {
      // Force process exit
      process.exit(1);
    }
  }

  private async handleGracefulShutdown(): Promise<void> {
    try {
      console.log('Handling graceful shutdown...');
      await this.logEmergencyEvent('GRACEFUL_SHUTDOWN', 'System shutdown requested');

      // Save any pending data
      // Close resources properly
      // Exit cleanly
      app.quit();

    } catch (error) {
      console.error('Error during graceful shutdown:', error);
      await this.forceExit();
    }
  }

  private async offerAutomaticRecovery(issues: string[]): Promise<void> {
    const result = await dialog.showMessageBox({
      type: 'warning',
      title: 'System Issues Detected',
      message: 'QuizLock has detected system issues that may affect operation.',
      detail: `Issues found:\n${issues.join('\n')}\n\nWould you like to attempt automatic recovery?`,
      buttons: ['Continue Monitoring', 'Attempt Recovery', 'Emergency Exit'],
      defaultId: 1
    });

    switch (result.response) {
      case 1: // Attempt Recovery
        await this.attemptRecovery();
        break;
      case 2: // Emergency Exit
        await this.requestEmergencyExit('User requested due to system issues');
        break;
      // Case 0: Continue monitoring (do nothing)
    }
  }

  private async promptForEmergencyCode(): Promise<string | null> {
    // This is a simplified implementation
    // In a real application, you'd want a proper secure dialog
    return new Promise((resolve) => {
      // For now, we'll use a simple approach
      // In production, this should be a proper modal dialog
      const mockCode = 'emergency2024'; // This would come from user input
      resolve(mockCode);
    });
  }

  private validateEmergencyCode(code: string): boolean {
    // This should validate against the secure admin system
    // For now, using default codes
    return this.emergencyExitCodes.includes(code) || code.length >= 12;
  }

  private isInGateMode(): boolean {
    // Check if any gate windows are open
    const windows = BrowserWindow.getAllWindows();
    return windows.some(window => 
      !window.isDestroyed() && 
      window.isFullScreen() && 
      window.isAlwaysOnTop()
    );
  }

  private async logEmergencyEvent(type: string, details: string): Promise<void> {
    try {
      const timestamp = new Date().toISOString();
      const logEntry = `[${timestamp}] ${type}: ${details}\n`;

      // Ensure log directory exists
      const logDir = path.dirname(this.emergencyLogPath);
      await fs.mkdir(logDir, { recursive: true });

      // Append to log file
      await fs.appendFile(this.emergencyLogPath, logEntry);

      console.log(`Emergency log: ${type} - ${details}`);
    } catch (error) {
      console.error('Failed to write emergency log:', error);
      // Don't throw - logging failure shouldn't break emergency procedures
    }
  }

  public async getEmergencyLogs(maxLines: number = 100): Promise<string[]> {
    try {
      const content = await fs.readFile(this.emergencyLogPath, 'utf-8');
      const lines = content.split('\n').filter(line => line.trim());
      return lines.slice(-maxLines); // Return last N lines
    } catch (error) {
      console.error('Error reading emergency logs:', error);
      return [];
    }
  }
}