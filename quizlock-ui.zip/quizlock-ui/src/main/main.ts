import { app, BrowserWindow, screen, globalShortcut, ipcMain, dialog, powerMonitor } from 'electron';
import * as path from 'path';
import { WindowManager } from './windowManager';
import { AgentCommunication } from './agentCommunication';
import { KeyboardBlocker } from './keyboardBlocker';
import { EmergencySystem } from './emergencySystem';

class QuizLockApp {
  private windowManager: WindowManager;
  private agentComm: AgentCommunication;
  private keyboardBlocker: KeyboardBlocker;
  private emergencySystem: EmergencySystem;
  private isInGateMode = false;
  private currentSession: any = null;

  constructor() {
    this.windowManager = new WindowManager();
    this.agentComm = new AgentCommunication();
    this.keyboardBlocker = new KeyboardBlocker();
    this.emergencySystem = EmergencySystem.getInstance();
    
    this.initializeApp();
  }

  private initializeApp() {
    // Handle app ready
    app.whenReady().then(() => {
      this.setupGlobalShortcuts();
      this.setupIpcHandlers();
      this.setupPowerMonitoring();
      
      // Check command line arguments
      const args = process.argv.slice(2);
      const isGateMode = args.includes('--gate');
      
      if (isGateMode) {
        this.startGateSession();
      } else {
        this.createMainWindow();
      }
    });

    // Handle window-all-closed
    app.on('window-all-closed', () => {
      if (!this.isInGateMode) {
        app.quit();
      }
      // In gate mode, don't quit when windows are closed
    });

    // Handle activate (macOS)
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        this.createMainWindow();
      }
    });

    // Handle before-quit
    app.on('before-quit', (event) => {
      if (this.isInGateMode) {
        // Prevent quit in gate mode unless authorized
        event.preventDefault();
        this.handleUnauthorizedExit();
      }
    });

    // Set up emergency system
    this.emergencySystem.registerGlobalEmergencyShortcuts();
    this.emergencySystem.scheduleHealthChecks();
  }

  private setupGlobalShortcuts() {
    // Teacher override shortcut (Ctrl+Shift+T)
    globalShortcut.register('CommandOrControl+Shift+T', () => {
      this.handleTeacherOverride();
    });

    // Emergency exit shortcut (Ctrl+Alt+Shift+E) - only in development
    if (process.env.NODE_ENV === 'development') {
      globalShortcut.register('CommandOrControl+Alt+Shift+E', () => {
        this.handleEmergencyExit();
      });
    }

    // Block common shortcuts in gate mode
    const blockedShortcuts = [
      'Alt+Tab',
      'Alt+F4',
      'CommandOrControl+Alt+Delete',
      'CommandOrControl+Shift+Escape',
      'CommandOrControl+R',
      'F11',
      'F12'
    ];

    blockedShortcuts.forEach(shortcut => {
      globalShortcut.register(shortcut, () => {
        if (this.isInGateMode) {
          console.log(`Blocked shortcut: ${shortcut}`);
          // Do nothing - effectively blocks the shortcut
        }
      });
    });
  }

  private setupIpcHandlers() {
    // Handle answer submission
    ipcMain.handle('submit-answer', async (event, data) => {
      return await this.handleAnswerSubmission(data);
    });

    // Handle gate completion
    ipcMain.handle('complete-gate', async (event) => {
      return await this.handleGateCompletion();
    });

    // Handle teacher override request
    ipcMain.handle('request-teacher-override', async (event) => {
      return await this.handleTeacherOverrideRequest();
    });

    // Get current cards for review
    ipcMain.handle('get-review-cards', async (event) => {
      return await this.agentComm.getReviewCards();
    });

    // Get gate progress
    ipcMain.handle('get-gate-progress', async (event) => {
      return {
        session: this.currentSession,
        isGateMode: this.isInGateMode
      };
    });

    // Teacher dashboard IPC handlers
    ipcMain.handle('validate-teacher-password', async (event, password: string) => {
      try {
        const result = await this.agentComm.validateTeacherPassword(password);
        return result;
      } catch (error) {
        console.error('Error validating teacher password:', error);
        return false;
      }
    });

    ipcMain.handle('get-student-stats', async () => {
      try {
        const stats = await this.agentComm.getStudentStats();
        return stats || [];
      } catch (error) {
        console.error('Error getting student stats:', error);
        return [];
      }
    });

    ipcMain.handle('get-system-stats', async () => {
      try {
        const stats = await this.agentComm.getSystemStats();
        return stats || {
          totalStudents: 0,
          totalSubmissions: 0,
          totalFlashcards: 0,
          submissionsToday: 0,
          reviewsToday: 0,
          dueCardsCount: 0,
          averageAccuracy: 0
        };
      } catch (error) {
        console.error('Error getting system stats:', error);
        return {
          totalStudents: 0,
          totalSubmissions: 0,
          totalFlashcards: 0,
          submissionsToday: 0,
          reviewsToday: 0,
          dueCardsCount: 0,
          averageAccuracy: 0
        };
      }
    });

    ipcMain.handle('get-system-logs', async (event, filter?: string) => {
      try {
        const logs = await this.agentComm.getSystemLogs(filter);
        return logs || [];
      } catch (error) {
        console.error('Error getting system logs:', error);
        return [];
      }
    });

    ipcMain.handle('update-system-settings', async (event, settings: any) => {
      try {
        const result = await this.agentComm.updateSystemSettings(settings);
        return result;
      } catch (error) {
        console.error('Error updating system settings:', error);
        throw error;
      }
    });

    ipcMain.handle('force-unlock-student', async (event, studentId: string) => {
      try {
        const result = await this.agentComm.forceUnlockStudent(studentId);
        return result;
      } catch (error) {
        console.error('Error force unlocking student:', error);
        throw error;
      }
    });

    ipcMain.handle('disable-gate-system', async () => {
      try {
        const result = await this.agentComm.disableGateSystem();
        return result;
      } catch (error) {
        console.error('Error disabling gate system:', error);
        throw error;
      }
    });

    ipcMain.handle('export-system-data', async () => {
      try {
        const result = await this.agentComm.exportSystemData();
        return result;
      } catch (error) {
        console.error('Error exporting system data:', error);
        throw error;
      }
    });

    ipcMain.handle('test-gate-mode', async () => {
      try {
        console.log('Test gate mode requested');
        // This would start a test gate session
        this.startGateSession();
        return true;
      } catch (error) {
        console.error('Error testing gate mode:', error);
        throw error;
      }
    });
  }

  private setupPowerMonitoring() {
    // Handle system suspend/resume
    powerMonitor.on('suspend', () => {
      console.log('System is going to sleep');
    });

    powerMonitor.on('resume', () => {
      console.log('System resumed from sleep');
      if (this.isInGateMode) {
        // Re-establish full-screen windows after resume
        setTimeout(() => {
          this.windowManager.ensureFullScreenCoverage();
        }, 1000);
      }
    });

    // Handle lock/unlock events
    powerMonitor.on('lock-screen', () => {
      console.log('Screen locked');
    });

    powerMonitor.on('unlock-screen', () => {
      console.log('Screen unlocked');
      // This could trigger a new gate session
      // depending on configuration from the Agent
    });
  }

  private createMainWindow() {
    const mainWindow = new BrowserWindow({
      width: 1200,
      height: 800,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        preload: path.join(__dirname, 'preload.js')
      },
      title: 'QuizLock Desktop',
      icon: path.join(__dirname, '../../assets/icon.png')
    });

    // Load the renderer
    const isDev = process.env.NODE_ENV === 'development';
    if (isDev) {
      mainWindow.loadURL('http://localhost:3000');
      mainWindow.webContents.openDevTools();
    } else {
      mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
    }

    // Handle window events
    mainWindow.on('closed', () => {
      if (!this.isInGateMode) {
        app.quit();
      }
    });
  }

  private async startGateSession() {
    console.log('Starting gate session...');
    this.isInGateMode = true;

    try {
      // Get cards from Agent
      const cards = await this.agentComm.getReviewCards();
      
      if (!cards || cards.length === 0) {
        console.log('No cards available, exiting gate mode');
        this.exitGateMode();
        return;
      }

      // Initialize session
      this.currentSession = {
        cards: cards,
        currentCardIndex: 0,
        correctCount: 0,
        requiredCorrect: 5,
        startTime: Date.now(),
        answers: []
      };

      // Create full-screen windows
      this.windowManager.createFullScreenWindows();
      
      // Enable keyboard blocking
      this.keyboardBlocker.enable();

      console.log(`Gate session started with ${cards.length} cards`);

    } catch (error) {
      console.error('Error starting gate session:', error);
      this.exitGateMode();
    }
  }

  private async handleAnswerSubmission(data: {
    cardId: string;
    answer: string;
    rating: number; // 1=Again, 2=Hard, 3=Good, 4=Easy
    timeSpent: number;
  }) {
    if (!this.currentSession) {
      throw new Error('No active gate session');
    }

    const { cardId, answer, rating, timeSpent } = data;
    const isCorrect = rating >= 3; // Good or Easy counts as correct

    // Record the answer
    this.currentSession.answers.push({
      cardId,
      answer,
      rating,
      isCorrect,
      timeSpent,
      timestamp: Date.now()
    });

    if (isCorrect) {
      this.currentSession.correctCount++;
    }

    // Send review to Agent
    await this.agentComm.submitReview({
      cardId,
      rating,
      timeSpent,
      timestamp: Date.now()
    });

    // Check if gate is complete
    if (this.currentSession.correctCount >= this.currentSession.requiredCorrect) {
      return { gateComplete: true };
    }

    // Move to next card or continue with current if incorrect
    if (isCorrect && this.currentSession.currentCardIndex < this.currentSession.cards.length - 1) {
      this.currentSession.currentCardIndex++;
    }

    return {
      gateComplete: false,
      correctCount: this.currentSession.correctCount,
      requiredCorrect: this.currentSession.requiredCorrect,
      currentCardIndex: this.currentSession.currentCardIndex
    };
  }

  private async handleGateCompletion() {
    if (!this.currentSession) {
      throw new Error('No active gate session');
    }

    console.log('Gate session completed successfully');

    // Record session completion with Agent
    await this.agentComm.recordGateCompletion({
      sessionId: `gate_${Date.now()}`,
      startTime: this.currentSession.startTime,
      endTime: Date.now(),
      correctCount: this.currentSession.correctCount,
      totalAnswers: this.currentSession.answers.length,
      answers: this.currentSession.answers
    });

    this.exitGateMode();
  }

  private async handleTeacherOverride() {
    if (!this.isInGateMode) return;

    console.log('Teacher override requested');

    // Show password dialog
    const result = await dialog.showMessageBox({
      type: 'question',
      title: 'Teacher Override',
      message: 'Enter teacher password to bypass gate:',
      buttons: ['Cancel', 'Enter Password'],
      defaultId: 1
    });

    if (result.response === 1) {
      // In a real implementation, this would show a proper password dialog
      // For now, we'll use a simple approach
      const password = await this.promptForPassword();
      
      if (await this.agentComm.validateTeacherPassword(password)) {
        console.log('Teacher override successful');
        
        await this.agentComm.recordTeacherOverride({
          timestamp: Date.now(),
          sessionId: this.currentSession?.startTime || Date.now()
        });

        this.exitGateMode();
      } else {
        console.log('Teacher override failed - incorrect password');
        dialog.showErrorBox('Access Denied', 'Incorrect teacher password');
      }
    }
  }

  private async handleTeacherOverrideRequest() {
    return this.handleTeacherOverride();
  }

  private async handleUnauthorizedExit() {
    console.log('Unauthorized exit attempt blocked');
    
    dialog.showWarningBox(
      'Access Restricted', 
      'You must complete the learning review to continue. Contact your teacher for assistance if needed.'
    );

    // Re-establish full screen windows if they were somehow closed
    this.windowManager.ensureFullScreenCoverage();
  }

  private async handleEmergencyExit() {
    console.log('Emergency exit triggered');
    
    await this.agentComm.recordEmergencyExit({
      timestamp: Date.now(),
      sessionId: this.currentSession?.startTime || Date.now()
    });

    this.forceExitGateMode();
  }

  private async promptForPassword(): Promise<string> {
    // This is a placeholder - in a real implementation, you'd want a proper secure dialog
    // For now, we'll return a test password
    return 'teacher123';
  }

  private exitGateMode() {
    console.log('Exiting gate mode...');
    
    this.isInGateMode = false;
    this.currentSession = null;
    
    // Disable keyboard blocking
    this.keyboardBlocker.disable();
    
    // Close full-screen windows
    this.windowManager.closeFullScreenWindows();
    
    // Quit the application
    app.quit();
  }

  private forceExitGateMode() {
    console.log('Force exiting gate mode...');
    
    this.isInGateMode = false;
    this.currentSession = null;
    
    this.keyboardBlocker.disable();
    this.windowManager.closeFullScreenWindows();
    
    // Force quit without checks
    app.exit(0);
  }
}

// Initialize the application
new QuizLockApp();