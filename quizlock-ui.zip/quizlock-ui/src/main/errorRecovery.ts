import { app, dialog, BrowserWindow } from 'electron';
import { EventEmitter } from 'events';
import * as fs from 'fs';
import * as path from 'path';

interface ErrorContext {
  timestamp: number;
  error: Error;
  component: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  userData?: any;
  systemState: 'gate_active' | 'normal' | 'starting' | 'shutting_down';
  recoveryAttempts: number;
  lastRecoveryTime?: number;
}

interface RecoveryStrategy {
  name: string;
  condition: (context: ErrorContext) => boolean;
  execute: (context: ErrorContext) => Promise<boolean>;
  maxAttempts: number;
  cooldownMs: number;
}

export class ErrorRecoverySystem extends EventEmitter {
  private static instance: ErrorRecoverySystem;
  private errorLog: ErrorContext[] = [];
  private recoveryStrategies: RecoveryStrategy[] = [];
  private activeRecoveries = new Map<string, number>();
  private systemHealthy = true;
  private criticalFailureCount = 0;
  private lastSystemCheck = Date.now();
  private recoveryWindow: Electron.BrowserWindow | null = null;
  
  private readonly config = {
    maxErrorsPerMinute: 10,
    criticalFailureThreshold: 3,
    systemCheckInterval: 30000, // 30 seconds
    errorRetentionDays: 7,
    emergencyExitThreshold: 5, // Critical failures before emergency exit
    logFilePath: path.join(process.cwd(), 'logs', 'error-recovery.log')
  };

  private constructor() {
    super();
    this.initializeRecoveryStrategies();
    this.startSystemMonitoring();
    this.setupGlobalErrorHandlers();
  }

  public static getInstance(): ErrorRecoverySystem {
    if (!ErrorRecoverySystem.instance) {
      ErrorRecoverySystem.instance = new ErrorRecoverySystem();
    }
    return ErrorRecoverySystem.instance;
  }

  private initializeRecoveryStrategies() {
    this.recoveryStrategies = [
      // Memory cleanup strategy
      {
        name: 'memory_cleanup',
        condition: (context) => {
          return context.error.message.includes('memory') || 
                 context.error.message.includes('heap') ||
                 (process.memoryUsage().heapUsed / 1024 / 1024 > 500); // 500MB
        },
        execute: async (context) => {
          try {
            // Force garbage collection
            if (global.gc) {
              global.gc();
            }
            
            // Clear any cached data
            await this.clearApplicationCache();
            
            // Limit memory usage
            app.commandLine.appendSwitch('--max-old-space-size', '512');
            
            this.logRecovery('memory_cleanup', 'Memory cleanup completed');
            return true;
          } catch (error) {
            this.logRecovery('memory_cleanup', `Memory cleanup failed: ${error.message}`);
            return false;
          }
        },
        maxAttempts: 3,
        cooldownMs: 30000
      },

      // Window recovery strategy
      {
        name: 'window_recovery',
        condition: (context) => {
          return context.component === 'window' || 
                 context.error.message.includes('window') ||
                 BrowserWindow.getAllWindows().length === 0;
        },
        execute: async (context) => {
          try {
            // Close any broken windows
            BrowserWindow.getAllWindows().forEach(window => {
              if (window.isDestroyed()) {
                return;
              }
              try {
                window.close();
              } catch (e) {
                window.destroy();
              }
            });

            // Wait a moment for cleanup
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Recreate main window
            this.emit('recreate-windows');
            
            this.logRecovery('window_recovery', 'Windows recreated successfully');
            return true;
          } catch (error) {
            this.logRecovery('window_recovery', `Window recovery failed: ${error.message}`);
            return false;
          }
        },
        maxAttempts: 3,
        cooldownMs: 5000
      },

      // Service connection recovery
      {
        name: 'service_reconnect',
        condition: (context) => {
          return context.component === 'agent_communication' ||
                 context.error.message.includes('ECONNREFUSED') ||
                 context.error.message.includes('service') ||
                 context.error.message.includes('connection');
        },
        execute: async (context) => {
          try {
            // Attempt to restart communication with the service
            this.emit('reconnect-service');
            
            // Wait for connection establishment
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            // Test connection
            this.emit('test-service-connection');
            
            this.logRecovery('service_reconnect', 'Service reconnection attempted');
            return true;
          } catch (error) {
            this.logRecovery('service_reconnect', `Service reconnection failed: ${error.message}`);
            return false;
          }
        },
        maxAttempts: 5,
        cooldownMs: 10000
      },

      // Database recovery strategy
      {
        name: 'database_recovery',
        condition: (context) => {
          return context.error.message.includes('database') ||
                 context.error.message.includes('SQLITE') ||
                 context.error.message.includes('corrupt');
        },
        execute: async (context) => {
          try {
            // Signal database recovery needed
            this.emit('recover-database');
            
            this.logRecovery('database_recovery', 'Database recovery initiated');
            return true;
          } catch (error) {
            this.logRecovery('database_recovery', `Database recovery failed: ${error.message}`);
            return false;
          }
        },
        maxAttempts: 2,
        cooldownMs: 60000
      },

      // Configuration reset strategy
      {
        name: 'config_reset',
        condition: (context) => {
          return context.error.message.includes('config') ||
                 context.error.message.includes('settings') ||
                 context.recoveryAttempts > 2;
        },
        execute: async (context) => {
          try {
            // Reset to default configuration
            this.emit('reset-configuration');
            
            this.logRecovery('config_reset', 'Configuration reset to defaults');
            return true;
          } catch (error) {
            this.logRecovery('config_reset', `Configuration reset failed: ${error.message}`);
            return false;
          }
        },
        maxAttempts: 1,
        cooldownMs: 300000 // 5 minutes
      },

      // Safe mode fallback
      {
        name: 'safe_mode',
        condition: (context) => {
          return context.severity === 'critical' ||
                 context.recoveryAttempts > 3 ||
                 this.criticalFailureCount >= this.config.criticalFailureThreshold;
        },
        execute: async (context) => {
          try {
            // Enter safe mode with minimal functionality
            this.emit('enter-safe-mode');
            
            await this.showRecoveryDialog({
              type: 'warning',
              title: 'QuizLock Safe Mode',
              message: 'QuizLock has entered safe mode due to repeated errors. Some features may be limited.',
              buttons: ['Continue in Safe Mode', 'Restart Application', 'Emergency Exit'],
              defaultId: 0
            });
            
            this.logRecovery('safe_mode', 'Entered safe mode successfully');
            return true;
          } catch (error) {
            this.logRecovery('safe_mode', `Safe mode entry failed: ${error.message}`);
            return false;
          }
        },
        maxAttempts: 1,
        cooldownMs: 0
      }
    ];
  }

  public async handleError(error: Error, component: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium', userData?: any): Promise<boolean> {
    const context: ErrorContext = {
      timestamp: Date.now(),
      error,
      component,
      severity,
      userData,
      systemState: this.getCurrentSystemState(),
      recoveryAttempts: 0,
      lastRecoveryTime: undefined
    };

    // Log the error
    await this.logError(context);

    // Add to error history
    this.errorLog.push(context);
    this.cleanOldErrors();

    // Check if system is experiencing too many errors
    if (this.isSystemUnstable()) {
      context.severity = 'critical';
      this.criticalFailureCount++;
    }

    // Increment failure count for critical errors
    if (severity === 'critical') {
      this.criticalFailureCount++;
    }

    // Check for emergency exit condition
    if (this.criticalFailureCount >= this.config.emergencyExitThreshold) {
      await this.handleEmergencyCondition(context);
      return false;
    }

    // Attempt recovery
    const recovered = await this.attemptRecovery(context);

    // Update system health status
    this.updateSystemHealth();

    // Emit recovery events
    this.emit('error-handled', { context, recovered });

    return recovered;
  }

  private async attemptRecovery(context: ErrorContext): Promise<boolean> {
    // Find applicable recovery strategies
    const applicableStrategies = this.recoveryStrategies.filter(strategy => 
      strategy.condition(context)
    );

    // Sort by priority (safe mode should be last)
    applicableStrategies.sort((a, b) => {
      if (a.name === 'safe_mode') return 1;
      if (b.name === 'safe_mode') return -1;
      return 0;
    });

    for (const strategy of applicableStrategies) {
      // Check if strategy is in cooldown
      const lastAttempt = this.activeRecoveries.get(strategy.name) || 0;
      const timeSinceLastAttempt = Date.now() - lastAttempt;
      
      if (timeSinceLastAttempt < strategy.cooldownMs) {
        continue;
      }

      // Check if we've exceeded max attempts for this strategy
      const recentAttempts = this.errorLog.filter(e => 
        Date.now() - e.timestamp < 300000 && // Last 5 minutes
        e.component === context.component
      ).length;

      if (recentAttempts >= strategy.maxAttempts) {
        continue;
      }

      try {
        this.logRecovery(strategy.name, `Attempting recovery strategy: ${strategy.name}`);
        
        // Record recovery attempt
        this.activeRecoveries.set(strategy.name, Date.now());
        context.recoveryAttempts++;
        context.lastRecoveryTime = Date.now();

        // Execute recovery strategy
        const success = await strategy.execute(context);

        if (success) {
          this.logRecovery(strategy.name, `Recovery successful: ${strategy.name}`);
          
          // Reset critical failure count on successful recovery
          if (context.severity === 'critical') {
            this.criticalFailureCount = Math.max(0, this.criticalFailureCount - 1);
          }
          
          return true;
        } else {
          this.logRecovery(strategy.name, `Recovery failed: ${strategy.name}`);
        }
      } catch (error) {
        this.logRecovery(strategy.name, `Recovery strategy error: ${strategy.name} - ${error.message}`);
      }
    }

    // If all strategies failed, consider emergency options
    if (context.severity === 'critical') {
      await this.handleCriticalFailure(context);
    }

    return false;
  }

  private async handleCriticalFailure(context: ErrorContext) {
    const response = await this.showRecoveryDialog({
      type: 'error',
      title: 'QuizLock Critical Error',
      message: `A critical error has occurred: ${context.error.message}\n\nWhat would you like to do?`,
      buttons: ['Try Emergency Recovery', 'Restart Application', 'Emergency Exit'],
      defaultId: 0
    });

    switch (response) {
      case 0: // Emergency Recovery
        await this.performEmergencyRecovery(context);
        break;
      case 1: // Restart
        this.logRecovery('critical_failure', 'User requested application restart');
        app.relaunch();
        app.exit(0);
        break;
      case 2: // Emergency Exit
        this.logRecovery('critical_failure', 'User requested emergency exit');
        this.emit('emergency-exit', 'USER_REQUEST');
        break;
    }
  }

  private async handleEmergencyCondition(context: ErrorContext) {
    this.logRecovery('emergency', `Emergency condition triggered: ${this.criticalFailureCount} critical failures`);

    const response = await this.showRecoveryDialog({
      type: 'error',
      title: 'QuizLock System Emergency',
      message: 'Multiple critical failures detected. The system may be unstable.\n\nEmergency options:',
      buttons: ['Safe Mode', 'Restart Now', 'Emergency Exit'],
      defaultId: 2
    });

    switch (response) {
      case 0: // Safe Mode
        await this.enterSafeMode();
        break;
      case 1: // Restart
        this.logRecovery('emergency', 'Emergency restart initiated');
        app.relaunch();
        app.exit(0);
        break;
      case 2: // Emergency Exit
        this.logRecovery('emergency', 'Emergency exit initiated');
        this.emit('emergency-exit', 'SYSTEM_UNSTABLE');
        break;
    }
  }

  private async performEmergencyRecovery(context: ErrorContext): Promise<boolean> {
    try {
      this.logRecovery('emergency_recovery', 'Starting emergency recovery sequence');

      // Step 1: Clear all cached data
      await this.clearApplicationCache();

      // Step 2: Reset configuration to defaults
      this.emit('reset-configuration', { emergency: true });

      // Step 3: Close and recreate all windows
      BrowserWindow.getAllWindows().forEach(window => {
        try {
          window.close();
        } catch (e) {
          window.destroy();
        }
      });

      await new Promise(resolve => setTimeout(resolve, 2000));

      // Step 4: Recreate minimal interface
      this.emit('recreate-windows', { safeMode: true });

      // Step 5: Reset error counters
      this.criticalFailureCount = 0;
      this.errorLog = [];
      this.systemHealthy = true;

      this.logRecovery('emergency_recovery', 'Emergency recovery completed');
      return true;

    } catch (error) {
      this.logRecovery('emergency_recovery', `Emergency recovery failed: ${error.message}`);
      return false;
    }
  }

  private async enterSafeMode(): Promise<void> {
    this.logRecovery('safe_mode', 'Entering safe mode');
    
    // Disable advanced features
    this.emit('enter-safe-mode', {
      disableGateMode: true,
      disableKeyboardBlocking: true,
      disableMonitoring: true,
      enableBasicFunctionality: true
    });

    // Show safe mode notification
    await this.showUserMessage({
      type: 'info',
      title: 'Safe Mode Active',
      message: 'QuizLock is running in safe mode. Some features are disabled for stability. Contact your IT administrator if this persists.'
    });
  }

  private async clearApplicationCache(): Promise<void> {
    try {
      // Clear Electron cache
      const windows = BrowserWindow.getAllWindows();
      for (const window of windows) {
        if (!window.isDestroyed()) {
          await window.webContents.session.clearCache();
          await window.webContents.session.clearStorageData();
        }
      }

      // Clear any temporary files
      this.emit('clear-temp-files');

    } catch (error) {
      console.error('Failed to clear application cache:', error);
    }
  }

  private async showRecoveryDialog(options: {
    type: string;
    title: string;
    message: string;
    buttons: string[];
    defaultId: number;
  }): Promise<number> {
    try {
      const response = await dialog.showMessageBox({
        type: options.type as any,
        title: options.title,
        message: options.message,
        buttons: options.buttons,
        defaultId: options.defaultId,
        cancelId: options.buttons.length - 1
      });
      
      return response.response;
    } catch (error) {
      console.error('Failed to show recovery dialog:', error);
      return options.defaultId;
    }
  }

  private async showUserMessage(options: {
    type: string;
    title: string;
    message: string;
  }): Promise<void> {
    try {
      // Create or show recovery notification window
      if (!this.recoveryWindow || this.recoveryWindow.isDestroyed()) {
        this.recoveryWindow = new BrowserWindow({
          width: 400,
          height: 200,
          modal: true,
          resizable: false,
          minimizable: false,
          maximizable: false,
          show: false,
          webPreferences: {
            nodeIntegration: false,
            contextIsolation: true
          }
        });

        const html = `
          <!DOCTYPE html>
          <html>
          <head>
            <title>${options.title}</title>
            <style>
              body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                padding: 20px;
                margin: 0;
                text-align: center;
                background: #f5f5f5;
              }
              .icon { font-size: 48px; margin-bottom: 15px; }
              h1 { font-size: 18px; margin: 0 0 15px 0; color: #333; }
              p { font-size: 14px; color: #666; line-height: 1.4; }
              button { 
                background: #007acc; 
                color: white; 
                border: none; 
                padding: 8px 16px; 
                border-radius: 4px;
                margin-top: 20px;
                cursor: pointer;
              }
            </style>
          </head>
          <body>
            <div class="icon">${options.type === 'info' ? 'ℹ️' : '⚠️'}</div>
            <h1>${options.title}</h1>
            <p>${options.message.replace(/\n/g, '<br>')}</p>
            <button onclick="window.close()">OK</button>
          </body>
          </html>
        `;

        await this.recoveryWindow.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(html)}`);
      }

      this.recoveryWindow.show();
      
      setTimeout(() => {
        if (this.recoveryWindow && !this.recoveryWindow.isDestroyed()) {
          this.recoveryWindow.close();
        }
      }, 5000);

    } catch (error) {
      console.error('Failed to show user message:', error);
    }
  }

  private setupGlobalErrorHandlers() {
    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception:', error);
      this.handleError(error, 'process', 'critical', { source: 'uncaughtException' });
    });

    // Handle unhandled promise rejections
    process.on('unhandledRejection', (reason, promise) => {
      const error = reason instanceof Error ? reason : new Error(String(reason));
      console.error('Unhandled Promise Rejection:', error);
      this.handleError(error, 'promise', 'high', { source: 'unhandledRejection', promise });
    });

    // Handle Electron-specific errors
    app.on('render-process-gone', (event, webContents, details) => {
      const error = new Error(`Renderer process crashed: ${details.reason}`);
      this.handleError(error, 'renderer', 'critical', { details, webContentsId: webContents.id });
    });

    app.on('child-process-gone', (event, details) => {
      const error = new Error(`Child process crashed: ${details.type} - ${details.reason}`);
      this.handleError(error, 'child_process', 'high', { details });
    });
  }

  private startSystemMonitoring() {
    setInterval(() => {
      this.performSystemHealthCheck();
    }, this.config.systemCheckInterval);

    // Initial health check
    setTimeout(() => this.performSystemHealthCheck(), 5000);
  }

  private async performSystemHealthCheck() {
    try {
      const currentTime = Date.now();
      const memoryUsage = process.memoryUsage();
      const windows = BrowserWindow.getAllWindows();

      // Check memory usage
      const memoryUsageMB = memoryUsage.heapUsed / 1024 / 1024;
      if (memoryUsageMB > 512) { // 512MB threshold
        this.handleError(
          new Error(`High memory usage detected: ${memoryUsageMB.toFixed(1)}MB`),
          'memory',
          'medium',
          { memoryUsage }
        );
      }

      // Check if windows are responsive
      for (const window of windows) {
        if (!window.isDestroyed() && !window.webContents.isLoading()) {
          try {
            // Test window responsiveness
            await window.webContents.executeJavaScript('true');
          } catch (error) {
            this.handleError(
              new Error('Window unresponsive'),
              'window',
              'high',
              { windowId: window.id }
            );
          }
        }
      }

      // Check error frequency
      const recentErrors = this.errorLog.filter(e => 
        currentTime - e.timestamp < 60000 // Last minute
      );

      if (recentErrors.length > this.config.maxErrorsPerMinute) {
        this.handleError(
          new Error(`High error rate: ${recentErrors.length} errors in the last minute`),
          'system',
          'critical',
          { recentErrorCount: recentErrors.length }
        );
      }

      this.lastSystemCheck = currentTime;
      
      // Emit health check event
      this.emit('health-check-completed', {
        timestamp: currentTime,
        memoryUsage: memoryUsageMB,
        windowCount: windows.length,
        errorCount: recentErrors.length,
        healthy: this.systemHealthy
      });

    } catch (error) {
      console.error('System health check failed:', error);
      this.handleError(error, 'health_check', 'medium');
    }
  }

  private isSystemUnstable(): boolean {
    const recentErrors = this.errorLog.filter(e => 
      Date.now() - e.timestamp < 60000 // Last minute
    );
    
    return recentErrors.length > this.config.maxErrorsPerMinute ||
           this.criticalFailureCount >= this.config.criticalFailureThreshold;
  }

  private updateSystemHealth() {
    const wasHealthy = this.systemHealthy;
    this.systemHealthy = !this.isSystemUnstable();
    
    if (wasHealthy !== this.systemHealthy) {
      this.emit('system-health-changed', this.systemHealthy);
      this.logRecovery('health_change', `System health changed: ${this.systemHealthy ? 'healthy' : 'unhealthy'}`);
    }
  }

  private getCurrentSystemState(): 'gate_active' | 'normal' | 'starting' | 'shutting_down' {
    // This would integrate with your main application state
    // For now, return a default
    return 'normal';
  }

  private cleanOldErrors() {
    const cutoff = Date.now() - (this.config.errorRetentionDays * 24 * 60 * 60 * 1000);
    this.errorLog = this.errorLog.filter(e => e.timestamp > cutoff);
  }

  private async logError(context: ErrorContext) {
    const logEntry = {
      timestamp: new Date(context.timestamp).toISOString(),
      component: context.component,
      severity: context.severity,
      message: context.error.message,
      stack: context.error.stack,
      systemState: context.systemState,
      userData: context.userData
    };

    try {
      // Ensure log directory exists
      const logDir = path.dirname(this.config.logFilePath);
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }

      // Write to log file
      const logLine = JSON.stringify(logEntry) + '\n';
      fs.appendFileSync(this.config.logFilePath, logLine);
      
      // Also log to console for debugging
      console.error(`[ErrorRecovery] ${logEntry.severity.toUpperCase()}: ${logEntry.message}`);
      
    } catch (error) {
      console.error('Failed to write error log:', error);
    }
  }

  private logRecovery(strategy: string, message: string) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      type: 'recovery',
      strategy,
      message
    };

    try {
      const logLine = JSON.stringify(logEntry) + '\n';
      fs.appendFileSync(this.config.logFilePath, logLine);
      console.log(`[Recovery] ${strategy}: ${message}`);
    } catch (error) {
      console.error('Failed to write recovery log:', error);
    }
  }

  // Public API methods
  public getSystemHealth(): boolean {
    return this.systemHealthy;
  }

  public getErrorStats(): { total: number; critical: number; lastHour: number } {
    const now = Date.now();
    const lastHour = this.errorLog.filter(e => now - e.timestamp < 3600000);
    const critical = this.errorLog.filter(e => e.severity === 'critical');

    return {
      total: this.errorLog.length,
      critical: critical.length,
      lastHour: lastHour.length
    };
  }

  public async exportErrorLogs(): Promise<string> {
    try {
      const logs = fs.readFileSync(this.config.logFilePath, 'utf8');
      return logs;
    } catch (error) {
      throw new Error(`Failed to export error logs: ${error.message}`);
    }
  }

  public clearErrorHistory(): void {
    this.errorLog = [];
    this.criticalFailureCount = 0;
    this.systemHealthy = true;
    this.logRecovery('clear_history', 'Error history cleared');
  }
}

export default ErrorRecoverySystem;