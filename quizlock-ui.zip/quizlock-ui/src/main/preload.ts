import { contextBridge, ipcRenderer } from 'electron';

// Define the API that will be exposed to the renderer process
const electronAPI = {
  // Gate session management
  async submitAnswer(data: {
    cardId: string;
    answer: string;
    rating: number;
    timeSpent: number;
  }) {
    return await ipcRenderer.invoke('submit-answer', data);
  },

  async completeGate() {
    return await ipcRenderer.invoke('complete-gate');
  },

  async getReviewCards() {
    return await ipcRenderer.invoke('get-review-cards');
  },

  async getGateProgress() {
    return await ipcRenderer.invoke('get-gate-progress');
  },

  // Teacher override
  async requestTeacherOverride() {
    return await ipcRenderer.invoke('request-teacher-override');
  },

  // Teacher dashboard APIs
  async validateTeacherPassword(password: string) {
    return await ipcRenderer.invoke('validate-teacher-password', password);
  },

  async getStudentStats() {
    return await ipcRenderer.invoke('get-student-stats');
  },

  async getSystemStats() {
    return await ipcRenderer.invoke('get-system-stats');
  },

  async getSystemLogs(filter?: string) {
    return await ipcRenderer.invoke('get-system-logs', filter);
  },

  async updateSystemSettings(settings: any) {
    return await ipcRenderer.invoke('update-system-settings', settings);
  },

  async forceUnlockStudent(studentId: string) {
    return await ipcRenderer.invoke('force-unlock-student', studentId);
  },

  async disableGateSystem() {
    return await ipcRenderer.invoke('disable-gate-system');
  },

  async exportSystemData() {
    return await ipcRenderer.invoke('export-system-data');
  },

  async testGateMode() {
    return await ipcRenderer.invoke('test-gate-mode');
  },

  // System information
  async getSystemInfo() {
    return {
      platform: process.platform,
      version: process.versions.electron,
      nodeVersion: process.versions.node
    };
  },

  // Event listeners
  onGateEvent(callback: (event: any, data: any) => void) {
    ipcRenderer.on('gate-event', callback);
    return () => ipcRenderer.removeListener('gate-event', callback);
  },

  onProgressUpdate(callback: (event: any, data: any) => void) {
    ipcRenderer.on('progress-update', callback);
    return () => ipcRenderer.removeListener('progress-update', callback);
  },

  onTeacherOverride(callback: (event: any, data: any) => void) {
    ipcRenderer.on('teacher-override', callback);
    return () => ipcRenderer.removeListener('teacher-override', callback);
  },

  // Utility functions
  log(level: 'info' | 'warn' | 'error', message: string, data?: any) {
    console[level](`[Renderer] ${message}`, data || '');
  },

  // Development helpers (only available in development)
  ...(process.env.NODE_ENV === 'development' ? {
    async devGetMockCards() {
      return [
        {
          id: 'dev_card_1',
          type: 'question',
          front: 'What is the capital of France?',
          options: ['London', 'Berlin', 'Paris', 'Madrid'],
          correctAnswer: 'Paris',
          dueAt: Date.now() - 1000000,
          interval: 1,
          easeFactor: 2.5,
          reviewCount: 0
        },
        {
          id: 'dev_card_2',
          type: 'cloze',
          front: 'The {{c1::mitochondria}} is the powerhouse of the cell.',
          back: 'mitochondria',
          dueAt: Date.now() - 500000,
          interval: 2,
          easeFactor: 2.6,
          reviewCount: 1
        }
      ];
    },
    
    devLog(message: string, data?: any) {
      console.log(`[DEV] ${message}`, data || '');
    }
  } : {})
};

// Expose the API to the renderer process
contextBridge.exposeInMainWorld('electronAPI', electronAPI);

// Also expose it as a global for easier access
declare global {
  interface Window {
    electronAPI: typeof electronAPI;
  }
}

// Log that preload script has loaded
console.log('QuizLock preload script loaded successfully');

// Handle any uncaught errors in the renderer process
window.addEventListener('error', (event) => {
  console.error('Renderer error:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection in renderer:', event.reason);
});