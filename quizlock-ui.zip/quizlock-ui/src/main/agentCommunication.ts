import * as net from 'net';

interface ReviewCard {
  id: string;
  type: 'question' | 'cloze' | 'summary';
  front: string;
  back?: string;
  options?: string[];
  correctAnswer?: string;
  dueAt: number;
  interval: number;
  easeFactor: number;
  reviewCount: number;
}

interface ReviewSubmission {
  cardId: string;
  rating: number; // 1=Again, 2=Hard, 3=Good, 4=Easy
  timeSpent: number;
  timestamp: number;
}

interface GateCompletion {
  sessionId: string;
  startTime: number;
  endTime: number;
  correctCount: number;
  totalAnswers: number;
  answers: any[];
}

export class AgentCommunication {
  private static readonly PIPE_NAME = '\\\\.\\pipe\\QuizLockAgent';
  private static readonly CONNECTION_TIMEOUT = 5000;
  private static readonly REQUEST_TIMEOUT = 10000;

  private isConnected = false;
  private currentConnection: net.Socket | null = null;

  constructor() {
    this.testConnection();
  }

  private async testConnection(): Promise<void> {
    try {
      await this.createConnection();
      console.log('Successfully connected to QuizLock Agent');
      this.isConnected = true;
    } catch (error) {
      console.error('Failed to connect to QuizLock Agent:', error);
      this.isConnected = false;
      
      // Retry connection every 30 seconds
      setTimeout(() => this.testConnection(), 30000);
    }
  }

  private async createConnection(): Promise<net.Socket> {
    return new Promise((resolve, reject) => {
      const socket = new net.Socket();
      let isResolved = false;

      const timeout = setTimeout(() => {
        if (!isResolved) {
          isResolved = true;
          socket.destroy();
          reject(new Error('Connection timeout'));
        }
      }, AgentCommunication.CONNECTION_TIMEOUT);

      socket.on('connect', () => {
        if (!isResolved) {
          isResolved = true;
          clearTimeout(timeout);
          resolve(socket);
        }
      });

      socket.on('error', (error) => {
        if (!isResolved) {
          isResolved = true;
          clearTimeout(timeout);
          reject(error);
        }
      });

      socket.connect(AgentCommunication.PIPE_NAME);
    });
  }

  private async sendRequest<T>(request: any): Promise<T> {
    if (!this.isConnected) {
      throw new Error('Not connected to QuizLock Agent');
    }

    return new Promise(async (resolve, reject) => {
      let socket: net.Socket;
      
      try {
        socket = await this.createConnection();
      } catch (error) {
        this.isConnected = false;
        this.testConnection(); // Restart connection attempts
        reject(new Error('Failed to connect to Agent: ' + error.message));
        return;
      }

      const requestId = Math.random().toString(36).substring(7);
      const message = {
        id: requestId,
        timestamp: Date.now(),
        ...request
      };

      let responseData = '';
      let isResolved = false;

      const timeout = setTimeout(() => {
        if (!isResolved) {
          isResolved = true;
          socket.destroy();
          reject(new Error('Request timeout'));
        }
      }, AgentCommunication.REQUEST_TIMEOUT);

      socket.on('data', (data) => {
        responseData += data.toString();
        
        // Check if we have a complete message (assuming newline-delimited JSON)
        const lines = responseData.split('\n');
        for (const line of lines) {
          if (line.trim()) {
            try {
              const response = JSON.parse(line);
              if (response.id === requestId) {
                if (!isResolved) {
                  isResolved = true;
                  clearTimeout(timeout);
                  socket.destroy();
                  
                  if (response.error) {
                    reject(new Error(response.error));
                  } else {
                    resolve(response.data);
                  }
                }
                return;
              }
            } catch (parseError) {
              // Continue waiting for more data
            }
          }
        }
      });

      socket.on('error', (error) => {
        if (!isResolved) {
          isResolved = true;
          clearTimeout(timeout);
          this.isConnected = false;
          this.testConnection();
          reject(error);
        }
      });

      socket.on('close', () => {
        if (!isResolved) {
          isResolved = true;
          clearTimeout(timeout);
          reject(new Error('Connection closed unexpectedly'));
        }
      });

      // Send the request
      socket.write(JSON.stringify(message) + '\n');
    });
  }

  public async getReviewCards(): Promise<ReviewCard[]> {
    try {
      console.log('Requesting review cards from Agent...');
      
      const response = await this.sendRequest<{ cards: ReviewCard[] }>({
        type: 'GetReviewCards',
        params: {
          maxCards: 20, // Get up to 20 cards
          includeDue: true,
          includeNew: true
        }
      });

      console.log(`Received ${response.cards.length} cards from Agent`);
      return response.cards;

    } catch (error) {
      console.error('Error getting review cards:', error);
      
      // Return mock data for development/testing
      if (process.env.NODE_ENV === 'development') {
        return this.getMockCards();
      }
      
      throw error;
    }
  }

  public async submitReview(review: ReviewSubmission): Promise<void> {
    try {
      console.log(`Submitting review for card ${review.cardId} with rating ${review.rating}`);
      
      await this.sendRequest({
        type: 'SubmitReview',
        params: review
      });

      console.log('Review submitted successfully');

    } catch (error) {
      console.error('Error submitting review:', error);
      
      // In development, just log the review
      if (process.env.NODE_ENV === 'development') {
        console.log('Mock review submission:', review);
        return;
      }
      
      throw error;
    }
  }

  public async recordGateCompletion(completion: GateCompletion): Promise<void> {
    try {
      console.log(`Recording gate completion: ${completion.sessionId}`);
      
      await this.sendRequest({
        type: 'RecordGateCompletion',
        params: completion
      });

      console.log('Gate completion recorded successfully');

    } catch (error) {
      console.error('Error recording gate completion:', error);
      
      if (process.env.NODE_ENV === 'development') {
        console.log('Mock gate completion:', completion);
        return;
      }
      
      throw error;
    }
  }

  public async validateTeacherPassword(password: string): Promise<boolean> {
    try {
      console.log('Validating teacher password...');
      
      const response = await this.sendRequest<{ valid: boolean; requiresSetup?: boolean }>({
        type: 'ValidateTeacherPassword',
        params: { password }
      });

      console.log(`Teacher password validation: ${response.valid}`);
      
      if (response.requiresSetup) {
        console.log('Teacher password requires initial setup');
        // Could trigger setup UI here
      }
      
      return response.valid;

    } catch (error) {
      console.error('Error validating teacher password:', error);
      
      // In development, accept setup password or configured password
      if (process.env.NODE_ENV === 'development') {
        return password === 'setup123' || password === 'teacher123';
      }
      
      return false;
    }
  }

  public async setTeacherPassword(currentPassword: string, newPassword: string): Promise<boolean> {
    try {
      console.log('Setting new teacher password...');
      
      const response = await this.sendRequest<{ success: boolean }>({
        type: 'SetTeacherPassword',
        params: { currentPassword, newPassword }
      });

      console.log(`Teacher password update: ${response.success}`);
      return response.success;

    } catch (error) {
      console.error('Error setting teacher password:', error);
      return false;
    }
  }

  public async validateEmergencyCode(code: string): Promise<boolean> {
    try {
      console.log('Validating emergency code...');
      
      const response = await this.sendRequest<{ valid: boolean }>({
        type: 'ValidateEmergencyCode',
        params: { code }
      });

      console.log(`Emergency code validation: ${response.valid}`);
      return response.valid;

    } catch (error) {
      console.error('Error validating emergency code:', error);
      
      // In development, accept default emergency codes
      if (process.env.NODE_ENV === 'development') {
        const defaultCodes = ['emergency2024', 'admin911', 'unlock123'];
        return defaultCodes.includes(code);
      }
      
      return false;
    }
  }

  public async recordTeacherOverride(data: { timestamp: number; sessionId: number }): Promise<void> {
    try {
      console.log('Recording teacher override...');
      
      await this.sendRequest({
        type: 'RecordTeacherOverride',
        params: data
      });

      console.log('Teacher override recorded successfully');

    } catch (error) {
      console.error('Error recording teacher override:', error);
      
      if (process.env.NODE_ENV === 'development') {
        console.log('Mock teacher override:', data);
        return;
      }
      
      throw error;
    }
  }

  public async recordEmergencyExit(data: { timestamp: number; sessionId: number }): Promise<void> {
    try {
      console.log('Recording emergency exit...');
      
      await this.sendRequest({
        type: 'RecordEmergencyExit',
        params: data
      });

      console.log('Emergency exit recorded successfully');

    } catch (error) {
      console.error('Error recording emergency exit:', error);
      
      if (process.env.NODE_ENV === 'development') {
        console.log('Mock emergency exit:', data);
        return;
      }
      
      throw error;
    }
  }

  public async getAgentStatus(): Promise<{ isRunning: boolean; version: string; studentId: string }> {
    try {
      const response = await this.sendRequest<{
        isRunning: boolean;
        version: string;
        studentId: string;
      }>({
        type: 'GetStatus'
      });

      return response;

    } catch (error) {
      console.error('Error getting agent status:', error);
      
      if (process.env.NODE_ENV === 'development') {
        return {
          isRunning: true,
          version: '1.0.0-dev',
          studentId: 'dev_student'
        };
      }
      
      throw error;
    }
  }

  public isAgentConnected(): boolean {
    return this.isConnected;
  }

  public async shutdown(): Promise<void> {
    if (this.currentConnection) {
      this.currentConnection.destroy();
      this.currentConnection = null;
    }
    this.isConnected = false;
  }

  // Mock data for development
  private getMockCards(): ReviewCard[] {
    const now = Date.now();
    const mockCards: ReviewCard[] = [
      {
        id: 'card_1',
        type: 'question',
        front: 'What is the capital of France?',
        options: ['London', 'Berlin', 'Paris', 'Madrid'],
        correctAnswer: 'Paris',
        dueAt: now - 1000000, // Overdue
        interval: 1,
        easeFactor: 2.5,
        reviewCount: 0
      },
      {
        id: 'card_2',
        type: 'cloze',
        front: 'The {{c1::mitochondria}} is the powerhouse of the cell.',
        back: 'mitochondria',
        dueAt: now - 500000,
        interval: 2,
        easeFactor: 2.6,
        reviewCount: 1
      },
      {
        id: 'card_3',
        type: 'question',
        front: 'Which planet is known as the Red Planet?',
        options: ['Venus', 'Mars', 'Jupiter', 'Saturn'],
        correctAnswer: 'Mars',
        dueAt: now,
        interval: 1,
        easeFactor: 2.5,
        reviewCount: 0
      },
      {
        id: 'card_4',
        type: 'summary',
        front: 'Summarize the main points of the article about artificial intelligence.',
        dueAt: now + 100000,
        interval: 3,
        easeFactor: 2.7,
        reviewCount: 2
      },
      {
        id: 'card_5',
        type: 'question',
        front: 'What is the chemical symbol for gold?',
        options: ['Go', 'Gd', 'Au', 'Ag'],
        correctAnswer: 'Au',
        dueAt: now - 200000,
        interval: 4,
        easeFactor: 2.8,
        reviewCount: 3
      }
    ];

    // Sort by due date (most overdue first)
    return mockCards.sort((a, b) => a.dueAt - b.dueAt);
  }
}