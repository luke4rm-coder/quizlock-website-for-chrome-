import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

// Get the URL parameters to determine mode
const urlParams = new URLSearchParams(window.location.search);
const mode = urlParams.get('mode') || 'normal';
const isPrimary = urlParams.get('primary') === 'true';

console.log(`QuizLock renderer starting in ${mode} mode (primary: ${isPrimary})`);

// Wait for DOM to be ready
const initApp = () => {
  const rootElement = document.getElementById('root');
  
  if (!rootElement) {
    console.error('Root element not found');
    return;
  }

  // Clear loading content
  rootElement.innerHTML = '';

  // Create React root and render app
  const root = createRoot(rootElement);
  
  root.render(
    <React.StrictMode>
      <App mode={mode} isPrimary={isPrimary} />
    </React.StrictMode>
  );

  // Show override hint in gate mode
  if (mode === 'gate') {
    const overrideHint = document.getElementById('override-hint');
    if (overrideHint) {
      overrideHint.classList.remove('hidden');
    }
  }
};

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}