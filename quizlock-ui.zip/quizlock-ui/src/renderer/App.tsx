import React, { useEffect, useState } from 'react';
import GateScreen from './components/GateScreen';
import MainScreen from './components/MainScreen';
import TeacherDashboard from './components/TeacherDashboard';

interface AppProps {
  mode: string;
  isPrimary: boolean;
}

interface AppState {
  isLoading: boolean;
  error: string | null;
  systemInfo: any;
  showTeacherDashboard: boolean;
}

const App: React.FC<AppProps> = ({ mode, isPrimary }) => {
  const [state, setState] = useState<AppState>({
    isLoading: true,
    error: null,
    systemInfo: null,
    showTeacherDashboard: false
  });

  useEffect(() => {
    const initializeApp = async () => {
      try {
        console.log('Initializing QuizLock app...');
        
        // Get system information
        const systemInfo = await window.electronAPI.getSystemInfo();
        console.log('System info:', systemInfo);
        
        setState(prev => ({
          ...prev,
          isLoading: false,
          systemInfo
        }));

        console.log(`QuizLock app initialized successfully in ${mode} mode`);
        
      } catch (error) {
        console.error('Error initializing app:', error);
        setState(prev => ({
          ...prev,
          isLoading: false,
          error: error instanceof Error ? error.message : 'Unknown error occurred'
        }));
      }
    };

    initializeApp();
  }, [mode]);

  // Handle keyboard events for the entire app
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Log all key events for debugging in development
      if (process.env.NODE_ENV === 'development') {
        console.log('Key pressed:', event.key, event.code, {
          ctrl: event.ctrlKey,
          shift: event.shiftKey,
          alt: event.altKey,
          meta: event.metaKey
        });
      }

      // Handle teacher override shortcut
      if (event.ctrlKey && event.shiftKey && event.key === 'T') {
        event.preventDefault();
        handleTeacherOverride();
        return;
      }

      // Handle teacher dashboard shortcut (Ctrl+Shift+D)
      if (event.ctrlKey && event.shiftKey && event.key === 'D') {
        event.preventDefault();
        setState(prev => ({ ...prev, showTeacherDashboard: true }));
        return;
      }

      // In gate mode, handle number keys for ratings
      if (mode === 'gate' && /^[1-4]$/.test(event.key)) {
        event.preventDefault();
        // Emit custom event that GateScreen can listen for
        window.dispatchEvent(new CustomEvent('rating-key', { 
          detail: { rating: parseInt(event.key) } 
        }));
        return;
      }

      // Block other potentially disruptive keys in gate mode
      if (mode === 'gate') {
        const blockedKeys = ['F11', 'F12', 'Escape'];
        if (blockedKeys.includes(event.key)) {
          event.preventDefault();
          console.log(`Blocked key: ${event.key}`);
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [mode]);

  const handleTeacherOverride = async () => {
    try {
      console.log('Teacher override requested via keyboard shortcut');
      await window.electronAPI.requestTeacherOverride();
    } catch (error) {
      console.error('Error requesting teacher override:', error);
    }
  };

  // Show loading screen
  if (state.isLoading) {
    return (
      <div className="gate-container">
        <div className="gate-title">QuizLock</div>
        <div className="gate-subtitle">Loading...</div>
      </div>
    );
  }

  // Show error screen
  if (state.error) {
    return (
      <div className="gate-container">
        <div className="gate-title" style={{ color: '#f44336' }}>Error</div>
        <div className="gate-subtitle">
          {state.error}
        </div>
        <div style={{ marginTop: '20px', fontSize: '14px', opacity: 0.7 }}>
          {process.env.NODE_ENV === 'development' && (
            <div>Development mode - check console for details</div>
          )}
        </div>
      </div>
    );
  }

  // Show teacher dashboard if requested
  if (state.showTeacherDashboard) {
    return (
      <TeacherDashboard 
        onClose={() => setState(prev => ({ ...prev, showTeacherDashboard: false }))}
      />
    );
  }

  // Render appropriate screen based on mode
  if (mode === 'gate') {
    return <GateScreen isPrimary={isPrimary} systemInfo={state.systemInfo} />;
  } else {
    return (
      <MainScreen 
        systemInfo={state.systemInfo}
        onOpenTeacherDashboard={() => setState(prev => ({ ...prev, showTeacherDashboard: true }))}
      />
    );
  }
};

export default App;