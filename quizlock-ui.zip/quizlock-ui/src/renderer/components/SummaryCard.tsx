import React, { useState, useEffect, useRef } from 'react';

interface ReviewCard {
  id: string;
  type: 'question' | 'cloze' | 'summary';
  front: string;
  back?: string;
  options?: string[];
  correctAnswer?: string;
  dueAt: number;
  interval: number;
  easeFactor: number;
  reviewCount: number;
}

interface SummaryCardProps {
  card: ReviewCard;
  onAnswerChange: (answer: string) => void;
  onRating: (rating: number) => void;
  currentAnswer: string;
  feedback: { type: 'correct' | 'incorrect' | null; message: string };
  disabled: boolean;
}

const SummaryCard: React.FC<SummaryCardProps> = ({
  card,
  onAnswerChange,
  onRating,
  currentAnswer,
  feedback,
  disabled
}) => {
  const [userSummary, setUserSummary] = useState<string>('');
  const [showComparison, setShowComparison] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const minLength = 100; // Minimum characters for summary

  useEffect(() => {
    // Reset state when card changes
    setUserSummary('');
    setShowComparison(false);
    setShowRating(false);
    onAnswerChange('');
    
    // Focus textarea after a brief delay
    setTimeout(() => {
      if (textareaRef.current && !disabled) {
        textareaRef.current.focus();
      }
    }, 100);
  }, [card.id, onAnswerChange, disabled]);

  useEffect(() => {
    // Update parent when summary changes
    onAnswerChange(userSummary);
  }, [userSummary, onAnswerChange]);

  const handleSummaryChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (disabled) return;
    setUserSummary(event.target.value);
  };

  const handleSubmitSummary = () => {
    if (userSummary.trim().length < minLength || disabled || showComparison) return;
    
    setShowComparison(true);
    
    // After showing comparison, allow self-assessment
    setTimeout(() => {
      setShowRating(true);
    }, 2000);
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && event.ctrlKey) {
      event.preventDefault();
      if (!showComparison && userSummary.trim().length >= minLength) {
        handleSubmitSummary();
      }
    }
  };

  const handleRating = (rating: number) => {
    if (!showRating || disabled) return;
    onRating(rating);
  };

  // Listen for keyboard ratings
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (showRating && !feedback.type) {
        const rating = parseInt(event.key);
        if (rating >= 1 && rating <= 4) {
          handleRating(rating);
          event.preventDefault();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [showRating, feedback.type]);

  const getWordCount = (text: string) => {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  };

  const getSimilarityScore = (summary1: string, summary2: string) => {
    // Simple similarity check - count common words
    const words1 = summary1.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    const words2 = summary2.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    
    const commonWords = words1.filter(word => words2.includes(word));
    const totalUniqueWords = new Set([...words1, ...words2]).size;
    
    if (totalUniqueWords === 0) return 0;
    return (commonWords.length * 2) / totalUniqueWords;
  };

  return (
    <div className="card-content">
      <div className="card-question" style={{ fontSize: '1.4rem', marginBottom: '25px' }}>
        {card.front}
      </div>
      
      {!showComparison && (
        <div style={{ marginTop: '20px' }}>
          <textarea
            ref={textareaRef}
            className="summary-textarea"
            value={userSummary}
            onChange={handleSummaryChange}
            onKeyDown={handleKeyPress}
            placeholder="Write your recall of the summary here. Try to remember the main points and key details..."
            disabled={disabled}
            style={{
              width: '100%',
              minHeight: '150px',
              padding: '20px',
              fontSize: '1.1rem',
              lineHeight: '1.5',
              background: 'rgba(255, 255, 255, 0.1)',
              border: '2px solid rgba(255, 255, 255, 0.2)',
              borderRadius: '15px',
              color: 'white',
              resize: 'vertical',
              fontFamily: 'inherit'
            }}
          />
          
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            marginTop: '15px',
            fontSize: '14px',
            opacity: 0.8
          }}>
            <div>
              Characters: {userSummary.length} / {minLength} minimum
              <br />
              Words: {getWordCount(userSummary)}
            </div>
            <div style={{ fontSize: '12px', textAlign: 'right' }}>
              Press Ctrl+Enter to submit
            </div>
          </div>
          
          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <button
              onClick={handleSubmitSummary}
              disabled={userSummary.trim().length < minLength || disabled}
              style={{
                background: userSummary.trim().length >= minLength
                  ? 'rgba(76, 175, 80, 0.3)' 
                  : 'rgba(255, 255, 255, 0.1)',
                border: '2px solid ' + (userSummary.trim().length >= minLength
                  ? '#4CAF50' 
                  : 'rgba(255, 255, 255, 0.2)'),
                borderRadius: '15px',
                padding: '15px 30px',
                color: 'white',
                fontSize: '1.1rem',
                cursor: userSummary.trim().length >= minLength ? 'pointer' : 'not-allowed',
                transition: 'all 0.3s ease'
              }}
            >
              Submit Summary
            </button>
          </div>
        </div>
      )}

      {showComparison && !showRating && (
        <div style={{ 
          marginTop: '20px',
          background: 'rgba(255, 255, 255, 0.05)',
          borderRadius: '15px',
          padding: '25px'
        }}>
          <h4 style={{ marginBottom: '20px', color: '#4CAF50' }}>
            Summary Comparison
          </h4>
          
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '20px',
            marginBottom: '20px'
          }}>
            <div>
              <h5 style={{ marginBottom: '10px', opacity: 0.9 }}>Your Recall:</h5>
              <div style={{
                background: 'rgba(33, 150, 243, 0.2)',
                border: '2px solid rgba(33, 150, 243, 0.4)',
                borderRadius: '10px',
                padding: '15px',
                fontSize: '0.95rem',
                lineHeight: '1.4',
                minHeight: '100px'
              }}>
                {userSummary}
              </div>
              <div style={{ fontSize: '12px', marginTop: '5px', opacity: 0.7 }}>
                {getWordCount(userSummary)} words
              </div>
            </div>
            
            <div>
              <h5 style={{ marginBottom: '10px', opacity: 0.9 }}>Original Summary:</h5>
              <div style={{
                background: 'rgba(76, 175, 80, 0.2)',
                border: '2px solid rgba(76, 175, 80, 0.4)',
                borderRadius: '10px',
                padding: '15px',
                fontSize: '0.95rem',
                lineHeight: '1.4',
                minHeight: '100px'
              }}>
                {card.back || 'Original summary content...'}
              </div>
              <div style={{ fontSize: '12px', marginTop: '5px', opacity: 0.7 }}>
                {getWordCount(card.back || '')} words
              </div>
            </div>
          </div>
          
          {card.back && (
            <div style={{ 
              textAlign: 'center', 
              marginBottom: '15px',
              fontSize: '14px',
              opacity: 0.8
            }}>
              Similarity Score: {Math.round(getSimilarityScore(userSummary, card.back) * 100)}%
            </div>
          )}
          
          <div style={{ 
            textAlign: 'center',
            fontSize: '1rem',
            opacity: 0.9
          }}>
            Compare your recall with the original. How well did you remember?
          </div>
        </div>
      )}

      {showRating && !feedback.type && (
        <div className="rating-prompt" style={{ marginTop: '20px' }}>
          <p style={{ marginBottom: '20px', fontSize: '1.2rem', textAlign: 'center' }}>
            How well did you recall the main points?
          </p>
          
          <div className="rating-buttons">
            <button
              className="rating-btn again"
              onClick={() => handleRating(1)}
              disabled={disabled}
            >
              <div>1 - Again</div>
              <small>Missed most points</small>
            </button>
            <button
              className="rating-btn hard"
              onClick={() => handleRating(2)}
              disabled={disabled}
            >
              <div>2 - Hard</div>
              <small>Got some points</small>
            </button>
            <button
              className="rating-btn good"
              onClick={() => handleRating(3)}
              disabled={disabled}
            >
              <div>3 - Good</div>
              <small>Most points recalled</small>
            </button>
            <button
              className="rating-btn easy"
              onClick={() => handleRating(4)}
              disabled={disabled}
            >
              <div>4 - Easy</div>
              <small>Excellent recall</small>
            </button>
          </div>
          
          <div style={{ 
            marginTop: '15px', 
            fontSize: '14px', 
            opacity: 0.7,
            textAlign: 'center'
          }}>
            Be honest - this helps optimize your learning schedule
          </div>
        </div>
      )}

      {feedback.type && (
        <div className={`feedback ${feedback.type}`}>
          <div style={{ fontSize: '1.2rem', marginBottom: '15px' }}>
            {feedback.message}
          </div>
          
          <div style={{ 
            fontSize: '1rem', 
            marginBottom: '15px',
            lineHeight: '1.4'
          }}>
            Your summary recall helps reinforce long-term memory of the key concepts.
            {feedback.type === 'correct' 
              ? " Great job connecting the main ideas!"
              : " Keep practicing active recall to strengthen your memory."}
          </div>
          
          <div style={{ 
            marginTop: '15px', 
            fontSize: '14px', 
            opacity: 0.8 
          }}>
            Summary exercises will be reviewed again based on your self-assessment.
          </div>
        </div>
      )}
    </div>
  );
};

export default SummaryCard;