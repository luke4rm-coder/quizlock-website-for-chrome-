import React, { useState, useEffect } from 'react';

interface Student {
  id: string;
  name: string;
  lastActive: number;
  totalSubmissions: number;
  totalReviews: number;
  averageAccuracy: number;
  dueCards: number;
  streak: number;
}

interface SystemStats {
  totalStudents: number;
  totalSubmissions: number;
  totalFlashcards: number;
  submissionsToday: number;
  reviewsToday: number;
  dueCardsCount: number;
  averageAccuracy: number;
}

interface LogEntry {
  timestamp: string;
  type: 'SYSTEM' | 'OVERRIDE' | 'EMERGENCY' | 'INFO';
  message: string;
  studentId?: string;
}

interface TeacherDashboardProps {
  onClose: () => void;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onClose }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [stats, setStats] = useState<SystemStats>({
    totalStudents: 0,
    totalSubmissions: 0,
    totalFlashcards: 0,
    submissionsToday: 0,
    reviewsToday: 0,
    dueCardsCount: 0,
    averageAccuracy: 0
  });
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'students' | 'settings' | 'logs'>('overview');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [logFilter, setLogFilter] = useState<string>('all');
  const [settings, setSettings] = useState({
    gateEnabled: true,
    requiredCorrectAnswers: 5,
    maxCardsPerSession: 20,
    allowTeacherOverride: true,
    allowEmergencyExit: true
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Load system stats, student data, and logs from the Agent
      const [systemStats, studentData, systemLogs] = await Promise.all([
        window.electronAPI.getSystemStats(),
        window.electronAPI.getStudentStats(),
        window.electronAPI.getSystemLogs()
      ]);
      
      setStats(systemStats);
      setStudents(studentData);
      setLogs(systemLogs || []);
      setIsLoading(false);
      
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      
      // Fall back to mock data on error
      setStats({
        totalStudents: 28,
        totalSubmissions: 156,
        totalFlashcards: 423,
        submissionsToday: 12,
        reviewsToday: 47,
        dueCardsCount: 89,
        averageAccuracy: 78.5
      });

      setStudents([
        {
          id: 'student_1',
          name: 'Alice Johnson',
          lastActive: Date.now() - 1800000,
          totalSubmissions: 23,
          totalReviews: 67,
          averageAccuracy: 85.2,
          dueCards: 3,
          streak: 7
        },
        {
          id: 'student_2', 
          name: 'Bob Smith',
          lastActive: Date.now() - 3600000,
          totalSubmissions: 18,
          totalReviews: 52,
          averageAccuracy: 72.1,
          dueCards: 8,
          streak: 4
        },
        {
          id: 'student_3',
          name: 'Carol Davis',
          lastActive: Date.now() - 7200000,
          totalSubmissions: 31,
          totalReviews: 89,
          averageAccuracy: 91.3,
          dueCards: 2,
          streak: 12
        }
      ]);
      
      setIsLoading(false);
    }
  };

  const handleSettingChange = async (key: string, value: any) => {
    try {
      // Update local state optimistically
      const previousSettings = settings;
      setSettings(prev => ({ ...prev, [key]: value }));
      
      // Send to Agent service
      await window.electronAPI.updateSystemSettings({ [key]: value });
      console.log(`Setting ${key} updated successfully`);
      
    } catch (error) {
      console.error('Error updating setting:', error);
      // Revert change on error
      setSettings(previousSettings);
      alert(`Failed to update setting: ${error.message || 'Unknown error'}`);
    }
  };

  const handleForceUnlock = async (studentId: string) => {
    try {
      const result = confirm(
        'Are you sure you want to force unlock this student\'s session? This will bypass the learning gate and will be logged.'
      );
      
      if (result) {
        await window.electronAPI.forceUnlockStudent(studentId);
        alert(`Force unlock executed for student. This action has been logged.`);
        
        // Refresh student data
        await loadDashboardData();
      }
    } catch (error) {
      console.error('Error forcing unlock:', error);
      alert(`Failed to force unlock: ${error.message || 'Unknown error'}`);
    }
  };

  const handleSystemDisable = async () => {
    const password = prompt('Enter teacher password to disable the gate system:');
    if (!password) return;

    try {
      // Validate teacher password
      const isValid = await window.electronAPI.validateTeacherPassword(password);
      
      if (isValid) {
        const confirmed = confirm(
          'This will disable the learning gate system for ALL students. Are you sure?'
        );
        
        if (confirmed) {
          await window.electronAPI.disableGateSystem();
          await handleSettingChange('gateEnabled', false);
          alert('Gate system disabled for all students. Re-enable when ready.');
        }
      } else {
        alert('Invalid teacher password.');
      }
    } catch (error) {
      console.error('Error disabling system:', error);
      alert(`Failed to disable system: ${error.message || 'Unknown error'}`);
    }
  };

  const loadLogs = async (filter: string = 'all') => {
    try {
      const systemLogs = await window.electronAPI.getSystemLogs(filter !== 'all' ? filter : undefined);
      setLogs(systemLogs || []);
    } catch (error) {
      console.error('Error loading logs:', error);
      // Fall back to mock logs
      setLogs([
        {
          timestamp: new Date(Date.now() - 300000).toISOString(),
          type: 'SYSTEM',
          message: 'Service started successfully'
        },
        {
          timestamp: new Date(Date.now() - 420000).toISOString(),
          type: 'OVERRIDE',
          message: 'Teacher override used',
          studentId: 'student_3'
        },
        {
          timestamp: new Date(Date.now() - 900000).toISOString(),
          type: 'EMERGENCY',
          message: 'Health check warning: High memory usage'
        }
      ]);
    }
  };

  const formatTimeAgo = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const getPerformanceColor = (accuracy: number) => {
    if (accuracy >= 85) return '#4CAF50';
    if (accuracy >= 70) return '#FF9800';
    return '#f44336';
  };

  if (isLoading) {
    return (
      <div className="teacher-dashboard loading">
        <div className="dashboard-header">
          <h1>Teacher Dashboard</h1>
          <button onClick={onClose} className="close-btn">×</button>
        </div>
        <div className="loading-content">
          <div>Loading dashboard data...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="teacher-dashboard">
      <div className="dashboard-header">
        <h1>🎓 QuizLock Teacher Dashboard</h1>
        <button onClick={onClose} className="close-btn">×</button>
      </div>

      <nav className="dashboard-nav">
        <button 
          className={`nav-btn ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          📊 Overview
        </button>
        <button 
          className={`nav-btn ${activeTab === 'students' ? 'active' : ''}`}
          onClick={() => setActiveTab('students')}
        >
          👥 Students
        </button>
        <button 
          className={`nav-btn ${activeTab === 'settings' ? 'active' : ''}`}
          onClick={() => setActiveTab('settings')}
        >
          ⚙️ Settings
        </button>
        <button 
          className={`nav-btn ${activeTab === 'logs' ? 'active' : ''}`}
          onClick={() => setActiveTab('logs')}
        >
          📋 Logs
        </button>
      </nav>

      <div className="dashboard-content">
        {activeTab === 'overview' && (
          <div className="overview-tab">
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-number">{stats.totalStudents}</div>
                <div className="stat-label">Active Students</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{stats.submissionsToday}</div>
                <div className="stat-label">Submissions Today</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{stats.reviewsToday}</div>
                <div className="stat-label">Reviews Today</div>
              </div>
              <div className="stat-card">
                <div className="stat-number" style={{ color: getPerformanceColor(stats.averageAccuracy) }}>
                  {stats.averageAccuracy.toFixed(1)}%
                </div>
                <div className="stat-label">Average Accuracy</div>
              </div>
            </div>

            <div className="quick-actions">
              <h3>Quick Actions</h3>
              <div className="action-buttons">
                <button 
                  className="action-btn emergency"
                  onClick={handleSystemDisable}
                >
                  🚨 Disable Gate System
                </button>
                <button 
                  className="action-btn secondary"
                  onClick={() => setActiveTab('settings')}
                >
                  ⚙️ System Settings
                </button>
                <button 
                  className="action-btn secondary"
                  onClick={async () => {
                    try {
                      await window.electronAPI.exportSystemData();
                      alert('System data exported successfully!');
                    } catch (error) {
                      console.error('Export error:', error);
                      alert(`Export failed: ${error.message || 'Unknown error'}`);
                    }
                  }}
                >
                  📤 Export Data
                </button>
              </div>
            </div>

            <div className="recent-activity">
              <h3>Recent Activity</h3>
              <div className="activity-list">
                <div className="activity-item">
                  <span className="activity-time">2 min ago</span>
                  <span className="activity-text">Alice Johnson completed 5 reviews</span>
                </div>
                <div className="activity-item">
                  <span className="activity-time">15 min ago</span>
                  <span className="activity-text">Bob Smith submitted quiz for "Science Article"</span>
                </div>
                <div className="activity-item">
                  <span className="activity-time">1h ago</span>
                  <span className="activity-text">Carol Davis triggered teacher override</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'students' && (
          <div className="students-tab">
            <div className="students-header">
              <h3>Student Management ({students.length} students)</h3>
              <button 
                className="refresh-btn"
                onClick={loadDashboardData}
              >
                🔄 Refresh
              </button>
            </div>

            <div className="students-grid">
              {students.map(student => (
                <div key={student.id} className="student-card">
                  <div className="student-header">
                    <div className="student-name">{student.name}</div>
                    <div className="student-status">
                      <span className="last-active">Last active: {formatTimeAgo(student.lastActive)}</span>
                    </div>
                  </div>
                  
                  <div className="student-stats">
                    <div className="stat">
                      <label>Accuracy:</label>
                      <span style={{ color: getPerformanceColor(student.averageAccuracy) }}>
                        {student.averageAccuracy.toFixed(1)}%
                      </span>
                    </div>
                    <div className="stat">
                      <label>Due Cards:</label>
                      <span className={student.dueCards > 5 ? 'high' : ''}>{student.dueCards}</span>
                    </div>
                    <div className="stat">
                      <label>Streak:</label>
                      <span>{student.streak} days</span>
                    </div>
                    <div className="stat">
                      <label>Submissions:</label>
                      <span>{student.totalSubmissions}</span>
                    </div>
                  </div>

                  <div className="student-actions">
                    <button 
                      className="action-btn small"
                      onClick={() => setSelectedStudent(student)}
                    >
                      📊 Details
                    </button>
                    <button 
                      className="action-btn small emergency"
                      onClick={() => handleForceUnlock(student.id)}
                    >
                      🔓 Force Unlock
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {selectedStudent && (
              <div className="student-detail-modal">
                <div className="modal-content">
                  <div className="modal-header">
                    <h3>{selectedStudent.name} - Detailed View</h3>
                    <button onClick={() => setSelectedStudent(null)}>×</button>
                  </div>
                  <div className="modal-body">
                    <div className="detail-stats">
                      <div className="detail-stat">
                        <label>Total Submissions:</label>
                        <span>{selectedStudent.totalSubmissions}</span>
                      </div>
                      <div className="detail-stat">
                        <label>Total Reviews:</label>
                        <span>{selectedStudent.totalReviews}</span>
                      </div>
                      <div className="detail-stat">
                        <label>Average Accuracy:</label>
                        <span style={{ color: getPerformanceColor(selectedStudent.averageAccuracy) }}>
                          {selectedStudent.averageAccuracy.toFixed(1)}%
                        </span>
                      </div>
                      <div className="detail-stat">
                        <label>Current Streak:</label>
                        <span>{selectedStudent.streak} days</span>
                      </div>
                      <div className="detail-stat">
                        <label>Cards Due:</label>
                        <span>{selectedStudent.dueCards}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="settings-tab">
            <h3>System Settings</h3>
            
            <div className="settings-section">
              <h4>Gate Configuration</h4>
              <div className="setting-item">
                <label>
                  <input 
                    type="checkbox" 
                    checked={settings.gateEnabled}
                    onChange={(e) => handleSettingChange('gateEnabled', e.target.checked)}
                  />
                  Enable Learning Gate
                </label>
                <p className="setting-description">
                  When enabled, students must complete review sessions to unlock their computers.
                </p>
              </div>
              
              <div className="setting-item">
                <label>
                  Required Correct Answers:
                  <input 
                    type="number" 
                    min="1" 
                    max="20"
                    value={settings.requiredCorrectAnswers}
                    onChange={(e) => handleSettingChange('requiredCorrectAnswers', parseInt(e.target.value))}
                  />
                </label>
                <p className="setting-description">
                  Number of correct answers students need to unlock the system.
                </p>
              </div>

              <div className="setting-item">
                <label>
                  Max Cards Per Session:
                  <input 
                    type="number" 
                    min="5" 
                    max="50"
                    value={settings.maxCardsPerSession}
                    onChange={(e) => handleSettingChange('maxCardsPerSession', parseInt(e.target.value))}
                  />
                </label>
                <p className="setting-description">
                  Maximum number of review cards to present in a single session.
                </p>
              </div>
            </div>

            <div className="settings-section">
              <h4>Safety & Access</h4>
              <div className="setting-item">
                <label>
                  <input 
                    type="checkbox" 
                    checked={settings.allowTeacherOverride}
                    onChange={(e) => handleSettingChange('allowTeacherOverride', e.target.checked)}
                  />
                  Allow Teacher Override
                </label>
                <p className="setting-description">
                  Permits teachers to bypass the gate using Ctrl+Shift+T shortcut.
                </p>
              </div>

              <div className="setting-item">
                <label>
                  <input 
                    type="checkbox" 
                    checked={settings.allowEmergencyExit}
                    onChange={(e) => handleSettingChange('allowEmergencyExit', e.target.checked)}
                  />
                  Enable Emergency Exit
                </label>
                <p className="setting-description">
                  Allows emergency exit codes for system recovery situations.
                </p>
              </div>
            </div>

            <div className="settings-actions">
              <button 
                className="action-btn primary"
                onClick={() => alert('Settings saved successfully!')}
              >
                💾 Save All Settings
              </button>
              <button 
                className="action-btn secondary"
                onClick={() => alert('Password change feature coming soon!')}
              >
                🔑 Change Teacher Password
              </button>
            </div>
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="logs-tab">
            <h3>System Logs</h3>
            <div className="logs-controls">
              <select 
                value={logFilter}
                onChange={(e) => {
                  setLogFilter(e.target.value);
                  loadLogs(e.target.value);
                }}
              >
                <option value="all">All Events</option>
                <option value="emergency">Emergency Events</option>
                <option value="override">Teacher Overrides</option>
                <option value="system">System Events</option>
              </select>
              <button 
                className="refresh-btn"
                onClick={() => loadLogs(logFilter)}
              >
                🔄 Refresh
              </button>
            </div>
            
            <div className="logs-list">
              {logs.length === 0 ? (
                <div className="no-logs">No logs found for the selected filter.</div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className={`log-entry ${log.type.toLowerCase()}`}>
                    <span className="log-time">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                    <span className="log-type">{log.type}</span>
                    <span className="log-message">
                      {log.message}
                      {log.studentId && ` (Student: ${log.studentId})`}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      <style>{`
        .teacher-dashboard {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          z-index: 10000;
          display: flex;
          flex-direction: column;
        }

        .dashboard-header {
          padding: 20px;
          border-bottom: 2px solid rgba(255, 255, 255, 0.2);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .dashboard-header h1 {
          margin: 0;
          font-size: 2rem;
          font-weight: 300;
        }

        .close-btn {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 2rem;
          width: 50px;
          height: 50px;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .close-btn:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        .dashboard-nav {
          display: flex;
          gap: 0;
          padding: 0 20px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nav-btn {
          background: transparent;
          border: none;
          color: rgba(255, 255, 255, 0.7);
          padding: 15px 25px;
          cursor: pointer;
          border-bottom: 3px solid transparent;
          transition: all 0.3s ease;
          font-size: 1rem;
        }

        .nav-btn:hover {
          color: white;
          background: rgba(255, 255, 255, 0.1);
        }

        .nav-btn.active {
          color: white;
          border-bottom-color: #4CAF50;
          background: rgba(255, 255, 255, 0.1);
        }

        .dashboard-content {
          flex: 1;
          padding: 30px;
          overflow-y: auto;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }

        .stat-card {
          background: rgba(255, 255, 255, 0.15);
          border-radius: 15px;
          padding: 25px;
          text-align: center;
          backdrop-filter: blur(10px);
        }

        .stat-number {
          font-size: 2.5rem;
          font-weight: bold;
          margin-bottom: 5px;
          color: #4CAF50;
        }

        .stat-label {
          font-size: 1rem;
          opacity: 0.9;
        }

        .quick-actions, .recent-activity {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 15px;
          padding: 25px;
          margin-bottom: 20px;
        }

        .action-buttons {
          display: flex;
          gap: 15px;
          flex-wrap: wrap;
        }

        .action-btn {
          padding: 12px 24px;
          border: none;
          border-radius: 25px;
          font-size: 1rem;
          cursor: pointer;
          transition: all 0.3s ease;
          font-weight: 500;
        }

        .action-btn.primary {
          background: #4CAF50;
          color: white;
        }

        .action-btn.secondary {
          background: rgba(255, 255, 255, 0.2);
          color: white;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .action-btn.emergency {
          background: #f44336;
          color: white;
        }

        .action-btn.small {
          padding: 8px 16px;
          font-size: 0.9rem;
        }

        .action-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .students-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
        }

        .student-card {
          background: rgba(255, 255, 255, 0.15);
          border-radius: 15px;
          padding: 20px;
          backdrop-filter: blur(10px);
        }

        .student-name {
          font-size: 1.2rem;
          font-weight: 600;
          margin-bottom: 5px;
        }

        .last-active {
          font-size: 0.9rem;
          opacity: 0.8;
        }

        .student-stats {
          margin: 15px 0;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        .stat {
          display: flex;
          justify-content: space-between;
          font-size: 0.9rem;
        }

        .stat label {
          opacity: 0.8;
        }

        .stat .high {
          color: #ff6b6b;
          font-weight: 600;
        }

        .student-actions {
          display: flex;
          gap: 10px;
        }

        .student-detail-modal {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 11000;
        }

        .modal-content {
          background: rgba(255, 255, 255, 0.95);
          color: #333;
          border-radius: 15px;
          padding: 30px;
          max-width: 500px;
          width: 90%;
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
          border-bottom: 2px solid #eee;
          padding-bottom: 15px;
        }

        .detail-stats {
          display: grid;
          gap: 15px;
        }

        .detail-stat {
          display: flex;
          justify-content: space-between;
          padding: 10px 0;
          border-bottom: 1px solid #eee;
        }

        .settings-section {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 15px;
          padding: 25px;
          margin-bottom: 20px;
        }

        .setting-item {
          margin-bottom: 20px;
        }

        .setting-item label {
          display: flex;
          align-items: center;
          gap: 10px;
          font-weight: 500;
          margin-bottom: 5px;
        }

        .setting-item input[type="checkbox"] {
          transform: scale(1.2);
        }

        .setting-item input[type="number"] {
          background: rgba(255, 255, 255, 0.2);
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-radius: 5px;
          padding: 8px;
          color: white;
          width: 80px;
          margin-left: 10px;
        }

        .setting-description {
          font-size: 0.9rem;
          opacity: 0.8;
          margin: 5px 0 0 0;
          line-height: 1.4;
        }

        .logs-list {
          background: rgba(0, 0, 0, 0.3);
          border-radius: 10px;
          padding: 20px;
          font-family: monospace;
          max-height: 400px;
          overflow-y: auto;
        }

        .log-entry {
          display: grid;
          grid-template-columns: 180px 100px 1fr;
          gap: 15px;
          padding: 8px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          font-size: 0.9rem;
        }

        .log-time {
          opacity: 0.8;
        }

        .log-type {
          font-weight: 600;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 0.8rem;
          text-align: center;
        }

        .log-entry.system .log-type {
          background: rgba(76, 175, 80, 0.3);
        }

        .log-entry.override .log-type {
          background: rgba(255, 152, 0, 0.3);
        }

        .log-entry.emergency .log-type {
          background: rgba(244, 67, 54, 0.3);
        }

        .activity-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .activity-item {
          display: flex;
          gap: 15px;
          padding: 10px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .activity-time {
          opacity: 0.7;
          font-size: 0.9rem;
          min-width: 80px;
        }

        .loading-content {
          display: flex;
          align-items: center;
          justify-content: center;
          height: 50%;
          font-size: 1.2rem;
        }

        .refresh-btn {
          background: rgba(255, 255, 255, 0.2);
          border: 2px solid rgba(255, 255, 255, 0.3);
          color: white;
          padding: 8px 16px;
          border-radius: 20px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .students-header, .logs-controls {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }

        .logs-controls select {
          background: rgba(255, 255, 255, 0.2);
          border: 2px solid rgba(255, 255, 255, 0.3);
          color: white;
          padding: 8px 12px;
          border-radius: 5px;
        }

        .no-logs {
          text-align: center;
          padding: 40px;
          opacity: 0.7;
          font-style: italic;
        }

        .log-entry.info .log-type {
          background: rgba(33, 150, 243, 0.3);
        }
      `}</style>
    </div>
  );
};

export default TeacherDashboard;