import React, { useState, useEffect, useRef } from 'react';

interface ReviewCard {
  id: string;
  type: 'question' | 'cloze' | 'summary';
  front: string;
  back?: string;
  options?: string[];
  correctAnswer?: string;
  dueAt: number;
  interval: number;
  easeFactor: number;
  reviewCount: number;
}

interface ClozeCardProps {
  card: ReviewCard;
  onAnswerChange: (answer: string) => void;
  onRating: (rating: number) => void;
  currentAnswer: string;
  feedback: { type: 'correct' | 'incorrect' | null; message: string };
  disabled: boolean;
}

const ClozeCard: React.FC<ClozeCardProps> = ({
  card,
  onAnswerChange,
  onRating,
  currentAnswer,
  feedback,
  disabled
}) => {
  const [userInput, setUserInput] = useState<string>('');
  const [showAnswer, setShowAnswer] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Reset state when card changes
    setUserInput('');
    setShowAnswer(false);
    setShowRating(false);
    onAnswerChange('');
    
    // Focus input after a brief delay
    setTimeout(() => {
      if (inputRef.current && !disabled) {
        inputRef.current.focus();
      }
    }, 100);
  }, [card.id, onAnswerChange, disabled]);

  useEffect(() => {
    // Update parent when input changes
    onAnswerChange(userInput);
  }, [userInput, onAnswerChange]);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;
    setUserInput(event.target.value);
  };

  const handleSubmitAnswer = () => {
    if (!userInput.trim() || disabled || showAnswer) return;
    
    setShowAnswer(true);
    
    // After showing the correct answer, allow rating
    setTimeout(() => {
      setShowRating(true);
    }, 1000);
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      if (!showAnswer) {
        handleSubmitAnswer();
      }
    }
  };

  const handleRating = (rating: number) => {
    if (!showRating || disabled) return;
    onRating(rating);
  };

  // Listen for keyboard ratings
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (showRating && !feedback.type) {
        const rating = parseInt(event.key);
        if (rating >= 1 && rating <= 4) {
          handleRating(rating);
          event.preventDefault();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [showRating, feedback.type]);

  // Parse cloze text to show blank
  const renderClozeText = () => {
    // Look for patterns like {{c1::word}} or {{word}}
    const clozePattern = /\{\{(?:c\d+::)?([^}]+)\}\}/g;
    let text = card.front;
    let match;
    let blanks = [];

    while ((match = clozePattern.exec(card.front)) !== null) {
      blanks.push(match[1]);
    }

    // Replace cloze deletions with input field or revealed answer
    text = text.replace(clozePattern, () => {
      if (showAnswer) {
        return `[${card.back || blanks[0] || 'ANSWER'}]`;
      } else {
        return '___________';
      }
    });

    return text;
  };

  return (
    <div className="card-content">
      <div className="card-question" style={{ fontSize: '1.6rem', lineHeight: '1.5' }}>
        {renderClozeText()}
      </div>
      
      {!showAnswer && (
        <div style={{ marginTop: '30px', textAlign: 'center' }}>
          <input
            ref={inputRef}
            type="text"
            className="cloze-input"
            value={userInput}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            placeholder="Fill in the blank..."
            disabled={disabled}
            style={{
              fontSize: '1.2rem',
              padding: '15px 20px',
              width: '300px',
              maxWidth: '90%',
              textAlign: 'center'
            }}
          />
          
          <div style={{ marginTop: '20px' }}>
            <button
              onClick={handleSubmitAnswer}
              disabled={!userInput.trim() || disabled}
              style={{
                background: userInput.trim() 
                  ? 'rgba(76, 175, 80, 0.3)' 
                  : 'rgba(255, 255, 255, 0.1)',
                border: '2px solid ' + (userInput.trim() 
                  ? '#4CAF50' 
                  : 'rgba(255, 255, 255, 0.2)'),
                borderRadius: '15px',
                padding: '15px 30px',
                color: 'white',
                fontSize: '1.1rem',
                cursor: userInput.trim() ? 'pointer' : 'not-allowed',
                transition: 'all 0.3s ease'
              }}
            >
              Submit Answer (or press Enter)
            </button>
          </div>
        </div>
      )}

      {showAnswer && !showRating && (
        <div style={{ 
          marginTop: '30px',
          background: 'rgba(255, 255, 255, 0.1)',
          borderRadius: '15px',
          padding: '25px',
          textAlign: 'center'
        }}>
          <div style={{ fontSize: '1.1rem', marginBottom: '15px', opacity: 0.9 }}>
            <strong>Your answer:</strong> {userInput}
          </div>
          <div style={{ fontSize: '1.3rem', marginBottom: '15px' }}>
            <strong>Correct answer:</strong> {card.back || 'ANSWER'}
          </div>
          <div style={{ fontSize: '0.9rem', opacity: 0.7 }}>
            How well did you know this?
          </div>
        </div>
      )}

      {showRating && !feedback.type && (
        <div className="rating-prompt" style={{ marginTop: '20px' }}>
          <p style={{ marginBottom: '20px', fontSize: '1.2rem', textAlign: 'center' }}>
            Rate how well you knew this answer:
          </p>
          
          <div className="rating-buttons">
            <button
              className="rating-btn again"
              onClick={() => handleRating(1)}
              disabled={disabled}
            >
              <div>1 - Again</div>
              <small>Didn't know it</small>
            </button>
            <button
              className="rating-btn hard"
              onClick={() => handleRating(2)}
              disabled={disabled}
            >
              <div>2 - Hard</div>
              <small>Partially correct</small>
            </button>
            <button
              className="rating-btn good"
              onClick={() => handleRating(3)}
              disabled={disabled}
            >
              <div>3 - Good</div>
              <small>Knew it well</small>
            </button>
            <button
              className="rating-btn easy"
              onClick={() => handleRating(4)}
              disabled={disabled}
            >
              <div>4 - Easy</div>
              <small>Perfect recall</small>
            </button>
          </div>
          
          <div style={{ 
            marginTop: '15px', 
            fontSize: '14px', 
            opacity: 0.7,
            textAlign: 'center'
          }}>
            Press 1-4 to rate your performance
          </div>
        </div>
      )}

      {feedback.type && (
        <div className={`feedback ${feedback.type}`}>
          <div style={{ fontSize: '1.2rem', marginBottom: '10px' }}>
            {feedback.message}
          </div>
          
          <div style={{ fontSize: '1rem', marginBottom: '10px' }}>
            <strong>Your answer:</strong> {userInput}
            <br />
            <strong>Correct answer:</strong> {card.back || 'ANSWER'}
          </div>
          
          <div style={{ 
            marginTop: '15px', 
            fontSize: '14px', 
            opacity: 0.8 
          }}>
            {feedback.type === 'correct' 
              ? "Excellent! This will be scheduled for future review." 
              : "Keep practicing! You'll remember better next time."}
          </div>
        </div>
      )}
    </div>
  );
};

export default ClozeCard;