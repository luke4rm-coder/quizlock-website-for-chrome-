import React, { useState, useEffect } from 'react';

interface ReviewCard {
  id: string;
  type: 'question' | 'cloze' | 'summary';
  front: string;
  back?: string;
  options?: string[];
  correctAnswer?: string;
  dueAt: number;
  interval: number;
  easeFactor: number;
  reviewCount: number;
}

interface QuestionCardProps {
  card: ReviewCard;
  onAnswerChange: (answer: string) => void;
  onRating: (rating: number) => void;
  currentAnswer: string;
  feedback: { type: 'correct' | 'incorrect' | null; message: string };
  disabled: boolean;
}

const QuestionCard: React.FC<QuestionCardProps> = ({
  card,
  onAnswerChange,
  onRating,
  currentAnswer,
  feedback,
  disabled
}) => {
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [showOptions, setShowOptions] = useState(true);

  useEffect(() => {
    // Reset selection when card changes
    setSelectedOption('');
    setShowOptions(true);
    onAnswerChange('');
  }, [card.id, onAnswerChange]);

  useEffect(() => {
    // Update parent when selection changes
    onAnswerChange(selectedOption);
  }, [selectedOption, onAnswerChange]);

  const handleOptionSelect = (option: string) => {
    if (disabled) return;
    
    setSelectedOption(option);
    setShowOptions(false);
    
    // Small delay then show rating buttons
    setTimeout(() => {
      // Answer is now selected, wait for rating
    }, 300);
  };

  const handleRating = (rating: number) => {
    if (!selectedOption || disabled) return;
    onRating(rating);
  };

  // Listen for keyboard number inputs
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (disabled) return;
      
      if (showOptions && card.options) {
        // Use 1-4 to select options
        const num = parseInt(event.key);
        if (num >= 1 && num <= Math.min(4, card.options.length)) {
          handleOptionSelect(card.options[num - 1]);
          event.preventDefault();
        }
      } else if (selectedOption && !feedback.type) {
        // Use 1-4 for rating (Again, Hard, Good, Easy)
        const rating = parseInt(event.key);
        if (rating >= 1 && rating <= 4) {
          handleRating(rating);
          event.preventDefault();
        }
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [showOptions, selectedOption, card.options, disabled, feedback.type]);

  return (
    <div className="card-content">
      <div className="card-question">{card.front}</div>
      
      {showOptions && card.options && (
        <div className="card-options">
          {card.options.map((option, index) => (
            <div
              key={index}
              className={`card-option ${selectedOption === option ? 'selected' : ''}`}
              onClick={() => handleOptionSelect(option)}
              style={{ 
                cursor: disabled ? 'not-allowed' : 'pointer',
                opacity: disabled ? 0.6 : 1 
              }}
            >
              <span className="option-number">{index + 1}.</span> {option}
            </div>
          ))}
          <div style={{ 
            marginTop: '20px', 
            fontSize: '14px', 
            opacity: 0.7,
            textAlign: 'center' 
          }}>
            Press 1-{Math.min(4, card.options.length)} to select your answer
          </div>
        </div>
      )}

      {!showOptions && selectedOption && !feedback.type && (
        <div className="answer-selected">
          <div style={{ 
            background: 'rgba(76, 175, 80, 0.2)',
            border: '2px solid #4CAF50',
            borderRadius: '15px',
            padding: '20px',
            marginBottom: '30px'
          }}>
            <strong>Your answer:</strong> {selectedOption}
          </div>
          
          <div className="rating-prompt">
            <p style={{ marginBottom: '20px', fontSize: '1.2rem' }}>
              How confident are you in this answer?
            </p>
            
            <div className="rating-buttons">
              <button
                className="rating-btn again"
                onClick={() => handleRating(1)}
                disabled={disabled}
              >
                <div>1 - Again</div>
                <small>Not confident</small>
              </button>
              <button
                className="rating-btn hard"
                onClick={() => handleRating(2)}
                disabled={disabled}
              >
                <div>2 - Hard</div>
                <small>Somewhat unsure</small>
              </button>
              <button
                className="rating-btn good"
                onClick={() => handleRating(3)}
                disabled={disabled}
              >
                <div>3 - Good</div>
                <small>Fairly confident</small>
              </button>
              <button
                className="rating-btn easy"
                onClick={() => handleRating(4)}
                disabled={disabled}
              >
                <div>4 - Easy</div>
                <small>Very confident</small>
              </button>
            </div>
            
            <div style={{ 
              marginTop: '15px', 
              fontSize: '14px', 
              opacity: 0.7 
            }}>
              Press 1-4 to rate your confidence
            </div>
          </div>
        </div>
      )}

      {feedback.type && (
        <div className={`feedback ${feedback.type}`}>
          <div style={{ fontSize: '1.2rem', marginBottom: '10px' }}>
            {feedback.message}
          </div>
          
          {feedback.type === 'incorrect' && card.correctAnswer && (
            <div style={{ fontSize: '1rem', opacity: 0.9 }}>
              <strong>Correct answer:</strong> {card.correctAnswer}
            </div>
          )}
          
          <div style={{ 
            marginTop: '15px', 
            fontSize: '14px', 
            opacity: 0.8 
          }}>
            {feedback.type === 'correct' 
              ? "Great! Moving to next question..." 
              : "Keep practicing! This will help you remember better."}
          </div>
        </div>
      )}
    </div>
  );
};

export default QuestionCard;