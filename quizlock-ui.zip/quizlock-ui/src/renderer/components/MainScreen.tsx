import React, { useState, useEffect } from 'react';

interface MainScreenProps {
  systemInfo: any;
  onOpenTeacherDashboard?: () => void;
}

const MainScreen: React.FC<MainScreenProps> = ({ systemInfo, onOpenTeacherDashboard }) => {
  const [stats, setStats] = useState({
    totalCards: 0,
    dueCards: 0,
    studiedToday: 0,
    avgAccuracy: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // In a full implementation, this would load actual stats
      // For now, we'll show a placeholder dashboard
      setTimeout(() => {
        setStats({
          totalCards: 45,
          dueCards: 8,
          studiedToday: 12,
          avgAccuracy: 87
        });
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setError('Failed to load dashboard data');
      setIsLoading(false);
    }
  };

  const handleTestGateMode = async () => {
    try {
      // This would launch a test gate session
      console.log('Test gate mode requested');
      alert('Test gate mode would launch here. This feature is for development/testing only.');
    } catch (error) {
      console.error('Error launching test gate:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="gate-container">
        <div className="gate-title">QuizLock Dashboard</div>
        <div className="gate-subtitle">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="gate-container">
        <div className="gate-title" style={{ color: '#f44336' }}>Error</div>
        <div className="gate-subtitle">{error}</div>
      </div>
    );
  }

  return (
    <div style={{
      padding: '40px',
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white'
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '50px' }}>
          <h1 style={{ 
            fontSize: '3rem', 
            fontWeight: 300, 
            marginBottom: '10px',
            textShadow: '2px 2px 4px rgba(0,0,0,0.3)'
          }}>
            QuizLock Dashboard
          </h1>
          <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>
            Learning Management & Statistics
          </p>
        </div>

        {/* Stats Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '25px',
          marginBottom: '50px'
        }}>
          <div className="stat-card">
            <div className="stat-number">{stats.totalCards}</div>
            <div className="stat-label">Total Cards</div>
          </div>
          <div className="stat-card">
            <div className="stat-number" style={{ color: stats.dueCards > 0 ? '#ff6b6b' : '#4ecdc4' }}>
              {stats.dueCards}
            </div>
            <div className="stat-label">Due for Review</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{stats.studiedToday}</div>
            <div className="stat-label">Studied Today</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">{stats.avgAccuracy}%</div>
            <div className="stat-label">Average Accuracy</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '20px',
          flexWrap: 'wrap',
          marginBottom: '50px'
        }}>
          <button 
            className="action-btn primary"
            onClick={() => window.close()}
          >
            📚 Start Study Session
          </button>
            <button 
              className="action-btn secondary"
              onClick={handleSettings}
            >
              ⚙️ Settings
            </button>
            
            <button 
              className="action-btn secondary"
              onClick={onOpenTeacherDashboard}
              title="Open Teacher Dashboard (Ctrl+Shift+D)"
            >
              🎓 Teacher Dashboard
            </button>
          <button 
            className="action-btn secondary"
            onClick={() => alert('Settings would open here')}
          >
            ⚙️ Settings
          </button>
        </div>

        {/* System Information */}
        <div style={{
          background: 'rgba(255, 255, 255, 0.1)',
          borderRadius: '15px',
          padding: '25px',
          marginBottom: '30px'
        }}>
          <h3 style={{ marginBottom: '20px', opacity: 0.9 }}>System Status</h3>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '15px',
            fontSize: '14px'
          }}>
            <div>
              <strong>Platform:</strong> {systemInfo?.platform || 'Unknown'}
            </div>
            <div>
              <strong>Electron:</strong> {systemInfo?.version || 'Unknown'}
            </div>
            <div>
              <strong>Node:</strong> {systemInfo?.nodeVersion || 'Unknown'}
            </div>
            <div>
              <strong>Status:</strong> <span style={{ color: '#4ecdc4' }}>✅ Running</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          textAlign: 'center',
          fontSize: '14px',
          opacity: 0.7,
          marginTop: '30px'
        }}>
          QuizLock Desktop v1.0.0 - Educational Spaced Repetition System
        </div>
      </div>

      {/* Embedded Styles */}
      <style>{`
        .stat-card {
          background: rgba(255, 255, 255, 0.15);
          border-radius: 20px;
          padding: 30px;
          text-align: center;
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .stat-number {
          font-size: 3rem;
          font-weight: bold;
          margin-bottom: 10px;
          color: #4ecdc4;
        }
        
        .stat-label {
          font-size: 1.1rem;
          opacity: 0.9;
        }
        
        .action-btn {
          padding: 15px 30px;
          border-radius: 25px;
          font-size: 1.1rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
          border: none;
          min-width: 200px;
        }
        
        .action-btn.primary {
          background: linear-gradient(45deg, #4CAF50, #45a049);
          color: white;
        }
        
        .action-btn.secondary {
          background: rgba(255, 255, 255, 0.2);
          color: white;
          border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        .action-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .action-btn.primary:hover {
          background: linear-gradient(45deg, #45a049, #4CAF50);
        }
        
        .action-btn.secondary:hover {
          background: rgba(255, 255, 255, 0.3);
        }
      `}</style>
    </div>
  );
};

export default MainScreen;