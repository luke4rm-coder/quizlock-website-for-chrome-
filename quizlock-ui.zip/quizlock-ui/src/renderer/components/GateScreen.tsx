import React, { useEffect, useState, useRef, useCallback } from 'react';
import QuestionCard from './QuestionCard';
import ClozeCard from './ClozeCard';
import SummaryCard from './SummaryCard';

interface ReviewCard {
  id: string;
  type: 'question' | 'cloze' | 'summary';
  front: string;
  back?: string;
  options?: string[];
  correctAnswer?: string;
  dueAt: number;
  interval: number;
  easeFactor: number;
  reviewCount: number;
}

interface GateProgress {
  session: {
    cards: ReviewCard[];
    currentCardIndex: number;
    correctCount: number;
    requiredCorrect: number;
    startTime: number;
    answers: any[];
  } | null;
  isGateMode: boolean;
}

interface GateScreenProps {
  isPrimary: boolean;
  systemInfo: any;
}

const GateScreen: React.FC<GateScreenProps> = ({ isPrimary, systemInfo }) => {
  const [cards, setCards] = useState<ReviewCard[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [requiredCorrect] = useState(5);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'correct' | 'incorrect' | null; message: string }>({ type: null, message: '' });
  const [isCompleted, setIsCompleted] = useState(false);
  const [sessionStartTime] = useState(Date.now());
  const [currentAnswer, setCurrentAnswer] = useState<string>('');
  
  const cardStartTimeRef = useRef<number>(Date.now());
  const ratingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Load cards and initialize gate session
  useEffect(() => {
    const initializeGate = async () => {
      try {
        console.log('Initializing gate session...');
        
        // Try to get current progress first
        const progress = await window.electronAPI.getGateProgress();
        console.log('Gate progress:', progress);
        
        if (progress.session && progress.session.cards.length > 0) {
          // Resume existing session
          setCards(progress.session.cards);
          setCurrentCardIndex(progress.session.currentCardIndex);
          setCorrectCount(progress.session.correctCount);
          console.log('Resumed existing gate session');
        } else {
          // Start new session
          const reviewCards = await window.electronAPI.getReviewCards();
          console.log('Loaded review cards:', reviewCards);
          
          if (reviewCards.length === 0) {
            throw new Error('No cards available for review');
          }
          
          setCards(reviewCards);
          setCurrentCardIndex(0);
          setCorrectCount(0);
        }
        
        setIsLoading(false);
        cardStartTimeRef.current = Date.now();
        
      } catch (error) {
        console.error('Error initializing gate:', error);
        setError(error instanceof Error ? error.message : 'Failed to initialize gate');
        setIsLoading(false);
      }
    };

    if (isPrimary) {
      initializeGate();
    } else {
      // Secondary screens just show a placeholder
      setIsLoading(false);
    }
  }, [isPrimary]);

  // Listen for keyboard rating events
  useEffect(() => {
    const handleRatingKey = (event: CustomEvent) => {
      const rating = event.detail.rating;
      if (rating >= 1 && rating <= 4 && !isCompleted && currentAnswer) {
        console.log(`Keyboard rating selected: ${rating}`);
        handleRating(rating);
      }
    };

    window.addEventListener('rating-key', handleRatingKey as EventListener);
    return () => window.removeEventListener('rating-key', handleRatingKey as EventListener);
  }, [currentAnswer, isCompleted]);

  const handleAnswerChange = useCallback((answer: string) => {
    setCurrentAnswer(answer);
  }, []);

  const handleRating = useCallback(async (rating: number) => {
    if (!currentAnswer || isCompleted) return;
    
    const currentCard = cards[currentCardIndex];
    if (!currentCard) return;

    // Clear any existing timeout
    if (ratingTimeoutRef.current) {
      clearTimeout(ratingTimeoutRef.current);
      ratingTimeoutRef.current = null;
    }

    const timeSpent = Date.now() - cardStartTimeRef.current;
    const isCorrect = rating >= 3; // Good (3) or Easy (4) count as correct

    try {
      console.log(`Submitting rating ${rating} for card ${currentCard.id}`);
      
      // Submit the answer to the main process
      const result = await window.electronAPI.submitAnswer({
        cardId: currentCard.id,
        answer: currentAnswer,
        rating: rating,
        timeSpent: timeSpent
      });

      // Show feedback
      const ratingNames = ['', 'Again', 'Hard', 'Good', 'Easy'];
      setFeedback({
        type: isCorrect ? 'correct' : 'incorrect',
        message: `${ratingNames[rating]} - ${isCorrect ? 'Correct!' : 'Try again next time'}`
      });

      // Update local state
      if (isCorrect) {
        setCorrectCount(prev => prev + 1);
      }

      // Check if gate is complete
      if (result.gateComplete) {
        console.log('Gate completed successfully');
        setIsCompleted(true);
        
        // Complete the gate after a short delay
        setTimeout(async () => {
          try {
            await window.electronAPI.completeGate();
          } catch (error) {
            console.error('Error completing gate:', error);
          }
        }, 2000);
        
      } else {
        // Move to next card after showing feedback
        ratingTimeoutRef.current = setTimeout(() => {
          if (isCorrect && currentCardIndex < cards.length - 1) {
            setCurrentCardIndex(prev => prev + 1);
          }
          
          setCurrentAnswer('');
          setFeedback({ type: null, message: '' });
          cardStartTimeRef.current = Date.now();
        }, 2000);
      }

    } catch (error) {
      console.error('Error submitting rating:', error);
      setError('Failed to submit answer. Please try again.');
    }
  }, [cards, currentCardIndex, currentAnswer, isCompleted]);

  const getCurrentCard = () => {
    return cards[currentCardIndex] || null;
  };

  const renderCard = () => {
    const card = getCurrentCard();
    if (!card) return null;

    const commonProps = {
      card,
      onAnswerChange: handleAnswerChange,
      onRating: handleRating,
      currentAnswer,
      feedback,
      disabled: feedback.type !== null
    };

    switch (card.type) {
      case 'question':
        return <QuestionCard {...commonProps} />;
      case 'cloze':
        return <ClozeCard {...commonProps} />;
      case 'summary':
        return <SummaryCard {...commonProps} />;
      default:
        return <div>Unknown card type: {card.type}</div>;
    }
  };

  // Secondary screen content
  if (!isPrimary) {
    return (
      <div className="gate-container">
        <div className="gate-title">QuizLock</div>
        <div className="gate-subtitle">Complete your review on the primary screen</div>
      </div>
    );
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="gate-container">
        <div className="gate-title">QuizLock</div>
        <div className="gate-subtitle">Loading review session...</div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="gate-container">
        <div className="gate-title" style={{ color: '#f44336' }}>Error</div>
        <div className="gate-subtitle">{error}</div>
        {process.env.NODE_ENV === 'development' && (
          <div style={{ marginTop: '20px', fontSize: '14px', opacity: 0.7 }}>
            Development mode - using mock data
          </div>
        )}
      </div>
    );
  }

  // Completion state
  if (isCompleted) {
    return (
      <div className="gate-container completion-screen fade-in">
        <div className="completion-title">🎉</div>
        <div className="completion-message">
          Excellent! You've completed your review session.
        </div>
        <div className="gate-subtitle">
          You got {correctCount} out of {requiredCorrect} correct answers.
          <br />
          You may now continue with your work.
        </div>
      </div>
    );
  }

  // Main gate interface
  const progressPercentage = (correctCount / requiredCorrect) * 100;

  return (
    <div className="gate-container">
      {/* Header */}
      <div className="gate-header">
        <div className="gate-title">Learning Review</div>
        <div className="gate-subtitle">
          Answer {requiredCorrect} questions correctly to continue
        </div>
      </div>

      {/* Progress */}
      <div className="progress-container">
        <div className="progress-text">
          Progress: {correctCount} / {requiredCorrect} correct
        </div>
        <div className="progress-bar">
          <div 
            className="progress-fill"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>

      {/* Current Card */}
      <div className="card-container fade-in">
        {renderCard()}
      </div>

      {/* Instructions */}
      <div style={{ 
        marginTop: '20px', 
        fontSize: '14px', 
        opacity: 0.8,
        textAlign: 'center'
      }}>
        Use keyboard: 1=Again, 2=Hard, 3=Good, 4=Easy
        <br />
        {process.env.NODE_ENV === 'development' && (
          <span style={{ opacity: 0.6 }}>
            DEV: Card {currentCardIndex + 1} of {cards.length} | Session: {Math.floor((Date.now() - sessionStartTime) / 1000)}s
          </span>
        )}
      </div>
    </div>
  );
};

export default GateScreen;